package com.ewbc.qa.web.framework.core;

import com.ewbc.qa.web.framework.base.BaseException;
import com.ewbc.qa.web.framework.base.BrowserHelper;
import com.ewbc.qa.web.framework.base.config.ConfigInput;
import com.ewbc.qa.web.framework.base.config.ConfigManger;
import com.ewbc.qa.web.framework.utility.FileUtils;
import com.ewbc.qa.web.framework.utility.UtilsException;
import com.ewbc.qa.web.framework.utility.WebEventListener;
import org.apache.commons.lang3.SystemUtils;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.ie.InternetExplorerOptions;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.remote.SessionId;
import org.openqa.selenium.support.events.EventFiringWebDriver;
import org.testng.log4testng.Logger;

import java.lang.reflect.Method;
import java.lang.Integer;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.BiConsumer;


/**
 * This class manages sessions for web automation testing.  Sessions are handled per thread basis,
 * where a given thread only has access to a single session (but multiple threads can exist, each with their own
 * session).
 */
public class DriverManager {
    public static EventFiringWebDriver e_driver;
    public static WebEventListener eventListener;

    private DriverManager() {
    }

    private static Logger _logger = Logger.getLogger(DriverManager.class);
    private static Map<Long, LinkedHashMap<SessionId, Session>> _sessions = new ConcurrentHashMap<>();
    private static Map<Long, Session> _activeSessions = new ConcurrentHashMap<>();
    private static AtomicInteger _sessionCount = new AtomicInteger();
    private static final int MAX_SESSION_TRIES = 3;

    /**
     * Creates a Desktop Browser Web Session
     *
     * @param testMethod Test method
     * @return session        Returns the Webdriver session.
     * @throws BaseException Session creation fails
     */
    public static WebDriver startWebSession(Method testMethod) throws BaseException {
        return startWebSession(testMethod, null, false, null);
    }

    /**
     * Creates a Desktop Browser Web Session
     *
     * @param testMethod         Test method
     * @param customCapabilities Custom capabilities to add to session
     * @return session            Returns the Webdriver session.
     * @throws BaseException Session creation fails
     */
    public static WebDriver startWebSession(Method testMethod, Map<String, Object> customCapabilities,boolean chromeExtension, String chromeExtensionPath) throws BaseException {
        //validate();
        Session session = null;
        try {
            // _logger.info("Starts the Desktop Web Browser session on " + ConfigManager.getInstance().getProperty(ConfigParameters.BROWSER));
            DesiredCapabilities capabilities = getWebCaps(testMethod, customCapabilities);
            WebDriver driver = getWebDriver(capabilities,chromeExtension, chromeExtensionPath);
            addEventListneres(driver);
            session = addSession(driver);
//            session.getDriver().manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
            
            if(ConfigManger.getProperty("implicitWaitTime") != null) {
            	int implicitWaitTime = Integer.parseInt(ConfigManger.getProperty("implicitWaitTime"));
            	_logger.info("Custom Implicit Wait Time: " + implicitWaitTime);
            	session.getDriver().manage().timeouts().implicitlyWait(implicitWaitTime, TimeUnit.SECONDS);
            } else {
            	session.getDriver().manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
            }
            
            if(ConfigManger.getProperty("pageLoadTimeout") != null) {
            	int pageLoadTimeout = Integer.parseInt(ConfigManger.getProperty("pageLoadTimeout"));
            	_logger.info("Custom Page Load Timeout: " + pageLoadTimeout);
            	session.getDriver().manage().timeouts().pageLoadTimeout(pageLoadTimeout, TimeUnit.SECONDS);
            } else {
            	session.getDriver().manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
            }
            session.getDriver().manage().window().maximize();
            session.getDriver().manage().deleteAllCookies();


            if (!ConfigManger.getProperty("Host").equals("localhost")) {
                new BrowserHelper().maximizeWindow();
            }

        } catch (Exception e) {
            if (session == null) {
                _sessionCount.decrementAndGet();
                throw new BaseException("Unable to create Session due to " + e.getMessage());
            }
        }
        return session.getDriver();
    }

    /**
     * Add EventListners
     *
     * @throws BaseException Driver instance is null
     */
    public static void addEventListneres(WebDriver driver) {
        e_driver = new EventFiringWebDriver(driver);
        eventListener = new WebEventListener();
        e_driver.register(eventListener);
        driver = e_driver;

		/*driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);*/
    }


    /**
     * Gets the driver instance.
     *
     * @return driver         Return the driver instance if exist
     * @throws BaseException Driver instance is null
     */
    public static WebDriver getDriver() throws BaseException {
        //addEventListneres(_driver);
        return getSession().getDriver();
    }

    /**
     * Get the session id for the current session.
     *
     * @return SessionId for the current session
     * @throws BaseException No valid session is available
     */
    public static SessionId getSessionId() throws BaseException {
        return getSession().getSessionId();
    }

    /**
     * Quits this session, closing every associated window.  Switches to the last created session if available.
     */
    public static void killSession() {
        killSession(true);
    }

    /**
     * Kill this session.  Switches to the last created session if available.
     *
     * @param quitSession Whether to quit underlying session
     */
    public static void killSession(boolean quitSession) {
        long threadId = Thread.currentThread().getId();
        LinkedHashMap<SessionId, Session> sessions = _sessions.get(threadId);
        if (sessions == null) {
            return;
        }
        if (!sessions.isEmpty()) {
            try {
                Session session = getSession();
                if (quitSession) {
                    //session.getDriver().close();
                    session.getDriver().quit();
                }
                sessions.remove(session.getSessionId());
                if (sessions.size() > 0) {
                    List<Entry<SessionId, Session>> s = new ArrayList<>(sessions.entrySet());
                    _activeSessions.put(threadId, s.get(s.size() - 1).getValue());
                } else {
                    _activeSessions.remove(threadId);
                }
            } catch (WebDriverException | BaseException e) {
                _logger.warn("Failed to get driver and quit session.");
            }
            _sessionCount.decrementAndGet();
            if (sessions.isEmpty()) {
                _sessions.remove(threadId);
            }
        }
    }

    /**
     * Kill all sessions associated with this thread, closing underlying sessions.
     */
    public static void killAllSessions() {
        killAllSessions(true);
    }

    /**
     * Kill all sessions associated with this thread.
     *
     * @param quitSession Whether to quit the underlying session
     */
    public static void killAllSessions(boolean quitSession) {
        long threadId = Thread.currentThread().getId();
        LinkedHashMap<SessionId, Session> sessions = _sessions.get(threadId);
        if (sessions == null) {
            return;
        }
        while (!sessions.isEmpty()) {
            killSession(quitSession);
        }
        _sessions.remove(threadId);
    }

    /**
     * Creates a firefox profile
     *
     * @return profile  FirefoxProfile
     */
    private static FirefoxProfile createFirefoxProfile() {
        FirefoxProfile profile = new FirefoxProfile();
//    profile.setPreference("network.proxy.type", 2);
//    profile.setPreference("network.proxy.ssl", "localhost");
//    profile.setPreference("network.proxy.ssl_port", 4444);
        return profile;
    }


    private static ChromeOptions createChromeOptions() {
        ChromeOptions chromeOptions = new ChromeOptions();

        return chromeOptions;
    }

    private static DesiredCapabilities getWebCaps(Method testMethod, Map<String, Object> customCapabilities) throws BaseException {
        String browserType = ConfigManger.getProperty("browser.name");
        DesiredCapabilities capabilities = null;
        switch (browserType) {
            case "firefox":
                FirefoxProfile profile = createFirefoxProfile();
                capabilities = DesiredCapabilities.firefox();
//                capabilities.setCapability(FirefoxDriver.PROFILE, profile);
                capabilities.setCapability("marionette", true);
                try {
                    String os = null;
                    String firefoxDriver = "geckodriver.exe";
                    if (SystemUtils.IS_OS_MAC_OSX) {
                        os = "mac";
                    } else if (SystemUtils.IS_OS_LINUX) {
                        os = "linux";
                        firefoxDriver += System.getProperty("sun.arch.data.model");
                    } else if (SystemUtils.IS_OS_WINDOWS) {
                        os = "windows";
                    }
                    System.setProperty("webdriver.gecko.driver"
                            , FileUtils.getResourcePath("/web/firefoxdriver/" + os + "/" + firefoxDriver, false, true));
                } catch (UtilsException e) {
                    throw new BaseException("Unable to find firefoxDriver");
                }
//        if (ConfigManager.getInstance().getPropertyAsBoolean(ConfigParameters.ENABLE_PROXY)) {
//          _logger.info("ENABLING PROXY AT " + ConfigManager.getInstance().getProperty(ConfigParameters.PROXY_URL));
//          Proxy proxy = new Proxy();
//          String proxyUrl = ConfigManager.getInstance().getProperty(ConfigParameters.PROXY_URL);
//          proxy.setHttpProxy(proxyUrl)
//          .setFtpProxy(proxyUrl)
//          .setSslProxy(proxyUrl);
//          capabilities.setCapability(CapabilityType.PROXY, proxy);
//        }
                break;
            case "chrome":
//                Proxy proxy = new Proxy();
//                proxy.setProxyType(Proxy.ProxyType.MANUAL);
//                proxy.setNoProxy("");
                ChromeOptions options = createChromeOptions();
                options.addArguments("disable-extensions");
//                options.setPageLoadStrategy(PageLoadStrategy.NONE);
                //options.addArguments("--start-maximized");
                //options.addArguments("--headless");
                capabilities = DesiredCapabilities.chrome();
                capabilities.setCapability(ChromeOptions.CAPABILITY, options);
//                capabilities.setCapability(CapabilityType.PROXY, proxy);
                capabilities.setCapability(CapabilityType.UNEXPECTED_ALERT_BEHAVIOUR, UnexpectedAlertBehaviour.IGNORE);
                
                try {
                    String os = null;
                    String chromeDriver = "chromedriver.exe";
                    if (SystemUtils.IS_OS_MAC_OSX) {
                        os = "mac";
                    } else if (SystemUtils.IS_OS_LINUX) {
                        os = "linux";
                        chromeDriver += System.getProperty("sun.arch.data.model");
                    } else if (SystemUtils.IS_OS_WINDOWS) {
                        os = "windows";
                    }
                    System.setProperty("webdriver.chrome.driver"
                            , FileUtils.getResourcePath("/web/chromedriver/" + os + "/" + chromeDriver, false, true));
                } catch (UtilsException e) {
                    throw new BaseException("Unable to find chromdriver");
                }
                break;
            case "iexplore":
                String iexplore = "IEDriverServer.exe";
                capabilities = DesiredCapabilities.internetExplorer();
                capabilities.setCapability(CapabilityType.UNEXPECTED_ALERT_BEHAVIOUR, UnexpectedAlertBehaviour.DISMISS);
                try {
                    System.setProperty("webdriver.ie.driver"
                            , FileUtils.getResourcePath("/web/iedriver/" + iexplore, false, true));
                } catch (UtilsException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
                break;
            case "msedge":
                String edgeDriver = "msedgedriver.exe";
                try {
                    System.setProperty("webdriver.edge.driver"
                            , FileUtils.getResourcePath("/web/msedgedriver/" + edgeDriver, false, true));
                } catch (UtilsException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
                break;
            default:
                throw new BaseException("Invalid browser: " + browserType);
        }

        if (customCapabilities != null) {
            addCustomCapabilities(capabilities, customCapabilities);
        }
        return capabilities;
    }


    /**
     * Creates the desired capabilities for Iphone Simulator
     *
     * @return capabilities Desired capabilities required for creating session on Iphone Simulator
     * @throws BaseException
     */

    private static WebDriver getWebDriver(DesiredCapabilities capabilities,boolean chromeExtension, String chromeExtensionPath) throws BaseException {
        try {
            String browserType = ConfigManger.getProperty("browser.name");
            if (ConfigManger.getProperty("Host").equals("localhost")) {
                switch (browserType) {
                    case "firefox":
                        FirefoxOptions firefoxOptions = new FirefoxOptions(capabilities);
//                        firefoxOptions.setLogLevel(FirefoxDriverLogLevel.DEBUG);
                        return new FirefoxDriver(firefoxOptions);
                    case "chrome":
                        return new ChromeDriver(capabilities);
                    case "iexplore":
                        return new InternetExplorerDriver(capabilities);
                    case "msedge":
                        EdgeOptions options = new EdgeOptions() ;
                        options.merge(capabilities);
                        return new EdgeDriver(options);
                    default:
                        throw new BaseException("Invalid browser: " + browserType);
                }
            } else {
                String remoteUrl = "http://" + ConfigManger.getProperty("Host") + ":"
                        + ConfigManger.getProperty("driver.port") + "/wd/hub";
                //System.out.println(remoteUrl);
//        DesiredCapabilities caps = new DesiredCapabilities().chrome();
//        caps.setPlatform(Platform.VISTA);
//        caps.setBrowserName("chrome");
                switch (browserType) {
                    case "firefox":
                        FirefoxOptions firefoxOptions = new FirefoxOptions(capabilities);
//                        firefoxOptions.setLogLevel(FirefoxDriverLogLevel.DEBUG);
                        return new RemoteWebDriver(new URL(remoteUrl), firefoxOptions);
                    case "chrome":
                        ChromeOptions chromeOptions = new ChromeOptions();
                        //options.addArguments("load-extension=C:\\Users\\crmtestuser2\\Desktop\\New folder\\auth_ext");
                        //WebDriver driver = new ChromeDriver(options);
                        if (chromeExtension == true) {
                        	chromeOptions.addArguments("load-extension="+chromeExtensionPath);
                        } else {
                        	chromeOptions.addArguments("load-extension=C:\\Extn\\crmtestuser2_auth_ext");
                        }
                        //WebDriver driver = new ChromeDriver(options);
                        //options.addArguments("load-extension="+chromeExtensionPath);
                        return new RemoteWebDriver(new URL(remoteUrl), chromeOptions);
                      
                        //return new RemoteWebDriver(new URL(remoteUrl), chromeOptions);
                    case "iexplore":
                        InternetExplorerOptions ieOptions = new InternetExplorerOptions(capabilities);
                        return new RemoteWebDriver(new URL(remoteUrl), ieOptions);
                    default:
                        throw new BaseException("Invalid browser: " + browserType);
                }

            }
        } catch (MalformedURLException e) {
            throw new BaseException("Unable to get web driver instance: " + e.getMessage());
        }
    }


    /**
     * Returns the Supergrid session URL
     *
     * @return gridUrl     Return the Supergrid session URL
     */
    public static String getGridUrl() throws BaseException {
        return getSession().getGridUrl();
    }

    /**
     * Returns whether there's a session.
     *
     * @return true if there's a session
     */
    public static boolean hasSession() {
        try {
            getSession();
        } catch (BaseException e) {
            return false;
        }
        return true;
    }

    /**
     * Switch the active session to given session id.
     *
     * @param sessionId SessionId to switch the active session to
     * @throws BaseException Session to switch to not found
     */
    public static void switchActiveSession(SessionId sessionId) throws BaseException {
        long threadId = Thread.currentThread().getId();
        LinkedHashMap<SessionId, Session> sessions = _sessions.get(threadId);
        if (sessions == null) {
            throw new BaseException("No valid sessions to switch");
        }
        Session activeSession = sessions.get(sessionId);
        if (activeSession == null) {
            throw new BaseException("Session does not exist: " + sessionId);
        }
        _activeSessions.put(threadId, activeSession);
    }

    private static Session getSession() throws BaseException {
        long threadId = Thread.currentThread().getId();
        LinkedHashMap<SessionId, Session> sessions = _sessions.get(threadId);
        if (sessions == null || sessions.isEmpty()) {
            throw new BaseException("No valid session available");
        }
        return _activeSessions.get(threadId);
    }

    private static boolean isSupergrid() {
        return ConfigManger.getProperty("Host").contains("supergrid");
    }

    private static Session addSession(WebDriver driver) {
        long threadId = Thread.currentThread().getId();
        LinkedHashMap<SessionId, Session> sessions = _sessions.get(threadId);
        if (sessions == null) {
            sessions = new LinkedHashMap<>();
            _sessions.put(threadId, sessions);
        }
        Session session = new Session(driver);
        sessions.put(session.getSessionId(), session);
        _activeSessions.put(threadId, session);
        return session;
    }

    private static String createGridUrl(SessionId sessionId) {
        if (ConfigManger.getProperty("Host").contains("supergrid")) {
            String gridUrl = "http://" + ConfigManger.getProperty("Host") + "/sessions/" + sessionId;
            _logger.info("Grid Url: " + gridUrl);
            return gridUrl;
        }
        return null;
    }

  /*private static void validate() throws BaseException {
    int maxNumSessions = ConfigManger.getPropertyAsInt(ConfigParameters.MAX_CONCURRENT_TESTS)
        * ConfigManger.getPropertyAsInt(ConfigParameters.MAX_CONCURRENT_SESSIONS_PER_THREAD);
    if (_sessionCount.incrementAndGet() > maxNumSessions) {
      _sessionCount.decrementAndGet();
      throw new BaseException("Number of active sessions exceeds maximum allowed of "
          + maxNumSessions);
    }
  }*/

    private static void addCustomCapabilities(final DesiredCapabilities capabilities, Map<String, Object> customCapabilities) {
        customCapabilities.forEach(new BiConsumer<String, Object>() {
            @Override
            public void accept(String key, Object value) {
                capabilities.setCapability(key, value);
            }
        });
    }

    private static class Session {
        private WebDriver _driver;
        private SessionId _sessionId;
        private String _gridUrl;

        public Session(WebDriver driver) {
            _driver = driver;
            _sessionId = ((RemoteWebDriver) _driver).getSessionId();
        }

        public WebDriver getDriver() {
            return _driver;
        }

        public SessionId getSessionId() {
            return _sessionId;
        }

        public void setGridUrl(String gridUrl) {
            _gridUrl = gridUrl;
        }

        public String getGridUrl() {
            return _gridUrl;
        }

    }
    public static void startNewWebSessionWithDifferentUser(Method method, boolean chromeExtension, String chromeExtensionPath) throws BaseException {
    	   // DriverManager.killAllSessions();
    	    DriverManager.startWebSession(method, null, chromeExtension, chromeExtensionPath);
    	    DriverManager.getDriver().get(ConfigInput.url);
    	  }
}