package com.ewbc.qa.web.framework.base;

import com.ewbc.qa.web.framework.base.config.ConfigInput;
import com.ewbc.qa.web.framework.base.config.ConfigManger;
import com.ewbc.qa.web.framework.core.DriverManager;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.ITestResult;
import org.testng.Reporter;
import org.testng.annotations.*;
import org.testng.asserts.Assertion;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Method;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;

public class BaseTest {
    private final static Logger log = Logger.getLogger(BaseTest.class);
    protected static ExtentReports extent;
    public WebDriver driver;
    public Method method;
    protected Assertion assertions;
    public static ExtentTest extentTest;
    private Map<String, Object> _customCapabilities;

    @BeforeSuite(alwaysRun = true)
    public void beforeSuite(ITestContext suite) throws Exception {
        // load the automation.properties file
        ConfigInput.init();
        //Currently we are using ExtentReportListener for extent report generation
        //TODO: Remove the below code after cleaning up logging statements in project
        extent = new ExtentReports(System.getProperty("user.dir") + "//test-output//JobResults_ExtentReport.html", true);
        // display the Environment details to the extent report Dashboard
        extent.addSystemInfo("Application URL", ConfigInput.url);
        extent.addSystemInfo("Browser", ConfigInput.browser);
    }

    @BeforeClass(alwaysRun = true)
    public void beforeClassRun() {
//        log.info("Started execution of Class:: " + testMethod.getClass().getSimpleName());
//        Reporter.log("Started execution of Class:: " + testMethod.getClass().getSimpleName());
    }

    @BeforeTest(alwaysRun = true)
    public void beforeTest() {

    }

    @Parameters({"browserName"})
    @BeforeMethod(alwaysRun = true)
    public final void mandatoryBeforeTestMethod(Method testMethod, @Optional() String browserName) throws BaseException {
        extentTest = extent.startTest((this.getClass().getSimpleName() + " :: " + testMethod.getName()),
                testMethod.getAnnotation(Test.class).description());
        Reporter.log("Started Test :: " + testMethod.getName());
        log.info("Started Test :: " + testMethod.getName());
        if (browserName != null) {
            ConfigManger.overrideProperty("browser.name", browserName);
        }
        driver = DriverManager.startWebSession(testMethod);
    }

    public WebDriver getDriver() {
        return driver;
    }

    public static File getScreenshot(WebDriver driver, String screenshotName) throws IOException, Exception {
        File finalDestination = null;
        try {
            String dateName = new SimpleDateFormat("yyyyMMdd").format(new Date());
            TakesScreenshot ts = (TakesScreenshot) driver;
            File source = ts.getScreenshotAs(OutputType.FILE);
            String destination = "./target/FailedTestsScreenshots/" + screenshotName + dateName
                    + ".png";
            finalDestination = new File(destination);
            FileUtils.copyFile(source, finalDestination);
        } catch (IOException e) {
            log.error("Failed to capture screenshot due to : " + e);
            Reporter.log("Failed to capture screenshot due to : " + e);
            Reporter.log("Failed to capture screenshot due to : " + e.getStackTrace().toString());
            log.info(e.getStackTrace().toString());
        }catch(Exception e){
            log.error("Failed to capture screenshot due to : " + e);
            Reporter.log("Failed to capture screenshot due to : " + e);
            Reporter.log("Failed to capture screenshot due to : " + e.getStackTrace().toString());
            log.info(e.getStackTrace().toString());
        }
        return finalDestination;
    }

    @AfterMethod(alwaysRun = true)
    public void tearDown(ITestResult result) throws IOException, BaseException {
    try {
        if (result.getStatus() == ITestResult.FAILURE) {
            log.info(result.getName() + ":: FAILED");
            Reporter.log(result.getName() + ":: FAILED");
        } else if (result.getStatus() == ITestResult.SKIP) {
            log.info(result.getName() + ":: SKIPPED");
            Reporter.log(result.getName() + ":: SKIPPED");
            Reporter.log(result.getThrowable() + ":: SKIPPED");
        } else if (result.getStatus() == ITestResult.SUCCESS) {
            log.info(result.getName() + ":: PASSED");
            Reporter.log(result.getName() + ":: PASSED");
        }

        if (result.getStatus() == ITestResult.FAILURE) {
            String filePath;
            File screenshotPath = BaseTest.getScreenshot(DriverManager.getDriver(), result.getName());
//            System.out.println("+++++++++++++++++++++++++++++++++++++++");
//            System.out.println(screenshotPath.getPath());
//            System.out.println(screenshotPath.getAbsolutePath());
//            System.out.println("+++++++++++++++++++++++++++++++++++++++");
            filePath = screenshotPath.getPath();
            // if(ConfigInput.imagelocation.contains("http")) {
            //	filePath = ConfigInput.imagelocation+screenshotPath.getPath();
            // }else {
            // 	filePath = screenshotPath.getAbsolutePath();
            // }
//            System.out.println("+++++++++++++++++++++++++++++++++++++++");
            filePath = filePath.replace("\\target", "");
//            System.out.println(filePath);
//            System.out.println("+++++++++++++++++++++++++++++++++++++++");
            extentTest.log(LogStatus.FAIL, extentTest.addScreenCapture(filePath)); // to add screenshot in extent
            extentTest.log(LogStatus.FAIL, "TEST CASE FAILED DUE TO " + result.getThrowable()); // to add error/exception in
            extentTest.log(LogStatus.FAIL, "TEST CASE FAILED IS " + result.getName()); // to add name in extent report														// extent report														// report
            // extentTest.log(LogStatus.FAIL, extentTest.addScreencast(screenshotPath));  // to add screencast/video in extent report
        } else if (result.getStatus() == ITestResult.SKIP) {
            extentTest.log(LogStatus.SKIP, "Test Case SKIPPED IS " + result.getName());
        } else if (result.getStatus() == ITestResult.SUCCESS) {
            extentTest.log(LogStatus.PASS, "Test Case PASSED IS " + result.getName());
            //if (ConfigManger.getProperty("enableScreenshotOnSuccess") != null && ConfigManger.getProperty("enableScreenshotOnSuccess").equalsIgnoreCase("true")) {
            if  (ConfigManger.getProperty("enableScreenshotOnSuccess").equalsIgnoreCase("true")) {
                String filePath;
                File screenshotPath = BaseTest.getScreenshot(DriverManager.getDriver(), result.getName());
                filePath = screenshotPath.getPath();
                filePath = filePath.replace("\\target", "");
                extentTest.log(LogStatus.PASS, extentTest.addScreenCapture(filePath)); // to add screenshot in extent

            }

        }
        DriverManager.killAllSessions(true);
        extent.endTest(extentTest);
    }catch(Exception e){
        log.error("Failed in BaseTest teardown : " + e);
        Reporter.log("Failed in BaseTest teardown  : " + e);
        Reporter.log("Failed in BaseTest teardown : " + e.getStackTrace().toString());
        log.info(e.getStackTrace().toString());
        Reporter.log("******************************Error while testcase teardown method*****************************************" );
        DriverManager.killAllSessions(true);
        extent.endTest(extentTest);
    }

    }

    @AfterTest(alwaysRun = true)
    public void afterTest() {
        extent.flush();

    }

    @AfterClass(alwaysRun = true)
    public void afterClassRun() {
//        log.info("Completed execution of Class:: " + testMethod.getClass().getSimpleName());
//        Reporter.log("Completed execution of Class:: " + testMethod.getClass().getSimpleName());
    }

    @AfterSuite(alwaysRun = true)
    public void afterSuite() {
//        Runtime.getRuntime().exec("taskkill /F /IM geckodriver.exe /T");
//        Runtime.getRuntime().exec("taskkill /F /IM chromedriver.exe /T");
//        Runtime.getRuntime().exec("taskkill /F /IM IEDriverServer.exe /T");
    }

    public void reportLog(String message) {
        message = System.lineSeparator() + message;
        Reporter.log(message);
    }

}
