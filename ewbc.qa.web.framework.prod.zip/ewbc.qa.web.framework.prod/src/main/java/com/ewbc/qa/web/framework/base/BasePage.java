package com.ewbc.qa.web.framework.base;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

public abstract class BasePage {

	public BasePage(WebDriver driver) throws BaseException {
		PageFactory.initElements(driver, this);
	}

}