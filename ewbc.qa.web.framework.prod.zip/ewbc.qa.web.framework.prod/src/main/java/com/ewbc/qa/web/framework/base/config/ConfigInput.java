package com.ewbc.qa.web.framework.base.config;

import java.io.IOException;
import java.net.URL;

import org.openqa.selenium.Capabilities;

/**
 * Created by rhegde on 06/03/2018.
 */
public class ConfigInput {
    public static String browser, url;
    public static int explicitWait;
    protected static URL gridhubUrl = null;
    protected static Capabilities capabilities = null;
    public static String imagelocation;

    /**
     * C O N F I G U R A T I O N I N P U T
     *
     * @throws IOException
     * @throws NumberFormatException
     */
    public static void init() throws NumberFormatException, IOException {
        ConfigManger config = new ConfigManger();
        if (config.hasProperty("app.url")
                && !"".equals(ConfigManger.getProperty("app.url"))) {
            gridhubUrl = new URL(config.getProperty("app.url"));
        }
        capabilities = config.getCaps();
        // explicitWait = Integer.parseInt(ConfigManger.getProperty("explicitWaitTime"));
        explicitWait = (ConfigManger.getProperty("explicitWaitTime") != null) ? Integer.parseInt(ConfigManger.getProperty("explicitWaitTime")) : 30;
        browser = ConfigManger.getProperty("browser.name");

        url = ConfigManger.getProperty("app.url");
        imagelocation = ConfigManger.getProperty("imageLocation");

    }
}
