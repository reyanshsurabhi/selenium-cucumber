package com.ewbc.qa.web.framework.utility;

import org.apache.log4j.Logger;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Date;

public class BaseDateUtils {
    public final static Logger log = Logger.getLogger(BaseDateUtils.class.getName());

    private BaseDateUtils() {

    }

    /**
     * Returns the current time in MM-dd-yyyy HH-mm-ss format
     *
     * @return Current Time as String in a  MM-dd-yyyy HH-mm-ss format
     */

    public static String getCurrentTime() {
        DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date today = Calendar.getInstance().getTime();
        return df.format(today);
    }

    /**
     * This method will return the date in specified format Example format::
     * "dd-MM-yyyy"
     *
     * @param format
     * @return
     * @throws Exception
     */
    public static String getCurrentDate(String format) throws Exception {
        SimpleDateFormat sdf = new SimpleDateFormat(format);
        String date = sdf.format(new Date());
        log.info("Date is =====" + date);
        return date;
    }

    /**
     * This method will return the date in specified format Example format::
     * "MM-dd-yyyy"
     *
     * @param format
     * @return
     * @throws Exception
     */
    public static String getDateMmDdYyyy(String format) throws Exception {
        DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
        Date date = new Date();
        String date1 = dateFormat.format(date);
        log.info("Date is =====" + date1);
        return date1;
    }

    /**
     * This method will return the Future date in specified format Example format::
     * "MM-dd-yyyy"
     *
     * @param format
     * @return
     * @throws Exception
     */
    public static String getFutureDate(String format) throws Exception {
        Calendar currentDate = Calendar.getInstance();
        currentDate.add(Calendar.DAY_OF_YEAR, 1);
        SimpleDateFormat formatter = new SimpleDateFormat(format);
        String date = formatter.format(currentDate.getTime());
        System.out.println(date);
        log.info("Date is =====" + date);
        return date;
    }

    /**
     * This method will return the Future date more than one month in specified format Example format::
     * "MM-dd-yyyy"
     *
     * @param format
     * @return
     * @throws Exception
     */

    public static String getFutureDateMoreThanOneMonth(String format) throws Exception {
        LocalDate futureDate = LocalDate.now().plusMonths(2);
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(format);
        String dateStr = futureDate.format(formatter);
        System.out.println(dateStr);
        log.info("Date is =====" + dateStr);
        return dateStr;
    }

    /**
     * This method will return the Future date for one month in specified format Example format::
     * "MM-dd-yyyy"
     *
     * @param format
     * @return
     * @throws Exception
     */

    public static String getOneMonthFutureDate(String format) throws Exception {
        LocalDate futureDate = LocalDate.now().plusMonths(1);
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(format);
        String dateStr = futureDate.format(formatter);
        System.out.println(dateStr);
        log.info("Date is =====" + dateStr);
        return dateStr;
    }

    /**
     * This method will return the next coming Sunday date in specified format Example format::
     * "MM-dd-yyyy"
     *
     * @param format
     * @return
     * @throws Exception
     */

    public static String getNextComingSundayDate(String format) throws Exception {
        String today = getCurrentDate("MM/dd/yyyy");
        Date date1 = new SimpleDateFormat("MM/dd/yyyy").parse(today);
        System.out.println(date1);
        Date date2 = getSunday(date1);
        DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
        String strDate = dateFormat.format(date2);
        System.out.println(strDate);
        return strDate;
    }

    /**
     * This method will return the next coming weekday after one month date in specified format Example format::
     * "MM-dd-yyyy"
     *
     * @param format
     * @return
     * @throws Exception
     */
    public static String getFutureDateSkippingWeekend(int workdays) {
        LocalDate date = LocalDate.now();
        int addedDays = 0;
        while (addedDays < workdays) {
            date = date.plusDays(1);
            if (!(date.getDayOfWeek() == DayOfWeek.SATURDAY || date.getDayOfWeek() == DayOfWeek.SUNDAY)) {
                ++addedDays;
            }
        }
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM/dd/yyyy");
        String dateStr = date.format(formatter);
        System.out.println(dateStr);
        return dateStr;
    }


    public static Date getSunday(Date today) {
        Calendar cal = Calendar.getInstance();

        cal.setTime(today);

        int dow = cal.get(Calendar.DAY_OF_WEEK);

        while (dow != Calendar.SUNDAY) {
            int date = cal.get(Calendar.DATE);

            int month = cal.get(Calendar.MONTH);

            int year = cal.get(Calendar.YEAR);

            if (date == getMonthLastDate(month, year)) {

                if (month == Calendar.DECEMBER) {
                    month = Calendar.JANUARY;

                    cal.set(Calendar.YEAR, year + 1);
                } else {
                    month++;
                }

                cal.set(Calendar.MONTH, month);

                date = 1;
            } else {
                date++;
            }

            cal.set(Calendar.DATE, date);

            dow = cal.get(Calendar.DAY_OF_WEEK);
            System.out.println(cal.getTime());
        }

        return cal.getTime();
    }

    private static int getMonthLastDate(int month, int year) {
        switch (month) {
            case Calendar.JANUARY:
            case Calendar.MARCH:
            case Calendar.MAY:
            case Calendar.JULY:
            case Calendar.AUGUST:
            case Calendar.OCTOBER:
            case Calendar.DECEMBER:
                return 31;

            case Calendar.APRIL:
            case Calendar.JUNE:
            case Calendar.SEPTEMBER:
            case Calendar.NOVEMBER:
                return 30;

            default:    //  Calendar.FEBRUARY
                return year % 4 == 0 ? 29 : 28;
        }
    }


    /**
     * This method will return the past date in specified format Example format::
     * "MM-dd-yyyy"
     *
     * @param format
     * @return
     * @throws Exception
     */
    public static String getpastDate(String format) throws Exception {
        Calendar currentDate = Calendar.getInstance();
        currentDate.add(Calendar.DAY_OF_YEAR, -1);
        SimpleDateFormat formatter = new SimpleDateFormat(format);
        String date = formatter.format(currentDate.getTime());
        System.out.println(date);
        log.info("Date is =====" + date);
        return date;
    }

    /**
     * This method will return the Future date in specified format Example format::
     * "MM-dd-yyyy"
     *
     * @param format
     * @return
     * @throws Exception
     */
    public static String getFutureDatePlusDays(String format, int days) throws Exception {
        Calendar currentDate = Calendar.getInstance();
        currentDate.add(Calendar.DAY_OF_YEAR, days);
        SimpleDateFormat formatter = new SimpleDateFormat(format);
        String date = formatter.format(currentDate.getTime());
        System.out.println(date);
        log.info("Date is =====" + date);
        return date;
    }
}
