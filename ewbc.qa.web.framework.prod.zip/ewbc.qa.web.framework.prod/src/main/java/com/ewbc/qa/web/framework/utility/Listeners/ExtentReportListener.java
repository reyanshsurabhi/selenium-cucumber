package com.ewbc.qa.web.framework.utility.Listeners;

//import com.ewbc.qa.web.framework.base.GroupsForReport;
import com.ewbc.qa.web.framework.base.config.ConfigInput;
import com.ewbc.qa.web.framework.base.config.ConfigManger;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.poi.common.usermodel.HyperlinkType;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.ss.util.WorkbookUtil;
import org.apache.poi.xssf.usermodel.*;
import org.testng.*;
import org.testng.xml.XmlSuite;

import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class ExtentReportListener implements IReporter {

    private ExtentReports extent;

    @Override
    public void generateReport(List<XmlSuite> xmlSuites, List<ISuite> suites, String outputDirectory) {
        extent = new ExtentReports(System.getProperty("user.dir") + "//target//ExtentReport.html", true);
        extent.loadConfig(new File(System.getProperty("user.dir") + "//src/main//resources//reportconfig.xml"));
        // display the Environment details to the extent report Dashboard
        extent.addSystemInfo("Application URL", ConfigInput.url);
        extent.addSystemInfo("Browser", ConfigInput.browser);

        for (ISuite suite : suites) {
            Map<String, ISuiteResult> result = suite.getResults();

            for (ISuiteResult r : result.values()) {
                ITestContext context = r.getTestContext();
                //Add all Passed Tests to ExtentReport
                buildTestNodes(context.getPassedTests(), LogStatus.PASS);

                /*
                 * Removing duplicate test results showing up in Extent Report due to Testng Retry Logic.
                 *
                 */

                // Delete Failed test if there are duplicates or if there is a Passed version
                IResultMap passedTests = context.getPassedTests();
                IResultMap failedTests = context.getFailedTests();
                Iterator<ITestResult> failedTestCases = failedTests.getAllResults().iterator();
                while (failedTestCases.hasNext()) {
                    ITestResult failedTestCase = failedTestCases.next();
                    ITestNGMethod method = failedTestCase.getMethod();
                    System.out.println("Failed Tests List :: Checking for duplicates of Method: " + failedTestCase.getMethod().getMethodName());
                    if (failedTests.getResults(method).size() > 1) {
                        System.out.println("Removing Failed test case as it has duplicate entry in Failed Tests: " + failedTestCase.getMethod().getMethodName());
                        failedTests.removeResult(method);
                    } else {
                        if (passedTests.getResults(method).size() > 0) {
                            System.out.println("Removing method from Failed tests as it has entry in Passed Tests: " + failedTestCase.getMethod().getMethodName());
                            failedTests.removeResult(method);
                        }
                    }
                }
                // Delete Skipped test if there is a Passed/Failed version
                IResultMap failedTestsUpdated = context.getFailedTests();
                IResultMap skippedTests = context.getSkippedTests();
                Iterator<ITestResult> skippedTestCases = skippedTests.getAllResults().iterator();
                while (skippedTestCases.hasNext()) {
                    ITestResult skippedTestCase = skippedTestCases.next();
                    ITestNGMethod method = skippedTestCase.getMethod();
                    System.out.println("Skipped Tests List :: Checking for duplicates of Method: " + skippedTestCase.getMethod().getMethodName());
                    if (skippedTests.getResults(method).size() > 1) {
                        System.out.println("Removing Skipped test case as it has duplicate entry in Skipped Tests: :" + skippedTestCase.getMethod().getMethodName());
                        skippedTests.removeResult(method);
                    } else {
                        if (failedTestsUpdated.getResults(method).size() > 0) {
                            System.out.println("Removing method from Skipped tests as it has entry in Failed Tests: " + skippedTestCase.getMethod().getMethodName());
                            skippedTests.removeResult(method);
                        }
                        if (passedTests.getResults(method).size() > 0) {
                            System.out.println("Removing method from Skipped tests as it has entry in Passed Tests: " + skippedTestCase.getMethod().getMethodName());
                            skippedTests.removeResult(method);
                        }
                    }
                }

                //Add all Failed Tests(except tests that have a Passed version) to ExtentReport
                buildTestNodes(context.getFailedTests(), LogStatus.FAIL);
                //Add all Skipped Tests(except tests that have a Passed/Failed version) to ExtentReport
                buildTestNodes(context.getSkippedTests(), LogStatus.SKIP);

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                try {
//                    generateTestReportExcel(passedTests, failedTestsUpdated, skippedTests);
//                } catch (IOException e) {
//                    e.printStackTrace();
//                }
            }
        }
        extent.flush();
        extent.close();
    }

    private void buildTestNodes(IResultMap tests, LogStatus status) {
        ExtentTest test = null;
        if (tests.size() > 0) {
            List<ITestResult> resultList = new LinkedList<>(tests.getAllResults());
            class ResultComparator implements Comparator<ITestResult> {
                public int compare(ITestResult r1, ITestResult r2) {
                    return getTime(r1.getStartMillis()).compareTo(getTime(r2.getStartMillis()));
                }
            }
            Collections.sort(resultList, new ResultComparator());
            for (ITestResult result : resultList) {
                //TODO: Split result.getMethod().getTestClass().getName() String to get only Test Class Name
                test = extent.startTest((result.getMethod().getTestClass().getName() + " :: " + result.getMethod().getMethodName()));
                //  test.getTest().setDescription(result.getMethod().getDescription());
                test.getTest().setStartedTime(getTime(result.getStartMillis()));
                test.getTest().setEndedTime(getTime(result.getEndMillis()));
                for (String group : result.getMethod().getGroups())
                    test.assignCategory(group);
                for (String message : Reporter.getOutput(result)) {    //This code picks the log from Reporter object.**
                    test.log(LogStatus.INFO, message);
                }

                if (result.getStatus() == ITestResult.FAILURE) {
                    test.log(LogStatus.FAIL, String.format("Test Case %s Failed", result.getName()));
                    test.log(LogStatus.FAIL, test.addScreenCapture(getScreenShotFilePath(result.getMethod().getMethodName())));
                } else if (result.getStatus() == ITestResult.SKIP) {
                    test.log(LogStatus.SKIP, String.format("Test Case %s Skipped", result.getName()));
                } else if (result.getStatus() == ITestResult.SUCCESS) {
                    test.log(LogStatus.PASS, String.format("Test Case %s Passed ", result.getName()));
                    if  (ConfigManger.getProperty("enableScreenshotOnSuccess").equalsIgnoreCase("true")) {
                        test.log(LogStatus.PASS, test.addScreenCapture(getScreenShotFilePath(result.getMethod().getMethodName())));
                    }
                } else {
                    test.log(LogStatus.INFO, "Test " + status.toString().toUpperCase() + "ED");
                }
                if (result.getThrowable() != null) {
                    test.log(LogStatus.INFO, result.getThrowable().getClass() + ": " + result.getThrowable().getMessage());
                    test.log(LogStatus.INFO, ExceptionUtils.getStackTrace(result.getThrowable()));
                }

                extent.endTest(test);
            }
        }
    }

    private Date getTime(long millis) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(millis);
        return calendar.getTime();
    }

    private String getScreenShotFilePath(String methodName) {
        String dateName = new SimpleDateFormat("yyyyMMdd").format(new Date());
//        String screenShotFilePath = "../../ws/target/FailedTestsScreenshots/" + methodName + dateName + ".png"; // Working for latests run
        String screenShotFilePath = ".\\FailedTestsScreenshots\\" + methodName + dateName + ".png";
        System.out.println("++++++++++++++++ getScreenShotFilePath Extent Report Listener +++++++++++++++++++++++");
        System.out.println(screenShotFilePath);
        System.out.println("+++++++++++++++++++++++++++++++++++++++");
        return screenShotFilePath;
    }

//    private void generateTestReportExcel(IResultMap passedTests, IResultMap failedTests, IResultMap skippedTests) throws IOException {
//        //EXCEL REPORTING
//
//        XSSFWorkbook workbook = new XSSFWorkbook();
//        XSSFSheet summarySheet = workbook.createSheet("SummaryReport");
//        int rowNum = 1;
//        summarySheet.setColumnWidth(1, 5000);
//        summarySheet.setColumnWidth(2, 4000);
//        summarySheet.setColumnWidth(3, 8000);
//        summarySheet.setColumnWidth(4, 8000);
//        summarySheet.setColumnWidth(5, 8000);
//        XSSFRow headerRow = summarySheet.createRow(rowNum++);
//
//        Cell cell1 = headerRow.createCell(1);
//        cell1.setCellStyle(getSummarySheetHeaderStyle(workbook));
//        cell1.setCellValue("Module");
//
//        Cell cell2 = headerRow.createCell(2);
//        cell2.setCellStyle(getSummarySheetHeaderStyle(workbook));
//        cell2.setCellValue("Total Test cases");
//
//        Cell cell3 = headerRow.createCell(3);
//        cell3.setCellStyle(getSummarySheetHeaderStyle(workbook));
//        cell3.setCellValue("Passed Test Cases");
//
//        Cell cell4 = headerRow.createCell(4);
//        cell4.setCellStyle(getSummarySheetHeaderStyle(workbook));
//        cell4.setCellValue("Failed Test Cases");
//
//        for (String group : GroupsForReport.groupsList) {
//            String sheetName = WorkbookUtil.createSafeSheetName(group);
//            XSSFRow summarySheetRow = summarySheet.createRow(rowNum++);
//            Cell summarySheetCell = summarySheetRow.createCell(1);
//            summarySheetCell.setCellValue(group);
//            summarySheetCell.setHyperlink(getSummarySheetModuleLink(workbook, group));
//            summarySheetCell.setCellStyle(getSummarySheetModuleLinkStyle(workbook));
//
//            XSSFSheet moduleSheet = workbook.createSheet(sheetName);
//            moduleSheet.setColumnWidth(0, 4000);
//            moduleSheet.setColumnWidth(1, 6000);
//            moduleSheet.setColumnWidth(2, 10000);
//            int[] rowCount = {0}; // Using int array to avoid "Variable used in lambda expression should be final or effectively final"
//            int columnCount = 0;
//
//            System.out.println("Group:: " + group);
//            System.out.println("Failed Test Cases List");
//            //Creating Failed List Header Row//
//            rowCount[0] = createHeadingTextRow(workbook, moduleSheet, rowCount[0], columnCount, "Failed");
//            int[] failedTestCount = {0};
//            failedTests.getAllMethods().forEach(testMethod -> {
//                for (String groupInTestMethod : testMethod.getGroups()) {
//                    if (groupInTestMethod.equals(group)) {
//                        String[] mthd = testMethod.getMethodName().split("_");
//                        System.out.println("Issue key: " + mthd[0]+ "-" +mthd[1]);
//                        System.out.println("Summary: " + mthd[2]);
//                        System.out.println("Description: " + testMethod.getDescription());
//
//                        XSSFRow failedTestRow = moduleSheet.createRow(rowCount[0]++);
//                        XSSFCell indexCell = failedTestRow.createCell(0);
//                        indexCell.setCellValue(++failedTestCount[0]);
//                        indexCell.setCellStyle(getTableCellStyle(workbook));
//
//                        XSSFCell issueKeyCell = failedTestRow.createCell(1);
//                        issueKeyCell.setCellValue(mthd[0]+ "-" +mthd[1]);
//                        issueKeyCell.setCellStyle(getTableCellStyle(workbook));
//
//                        XSSFCell summaryCell = failedTestRow.createCell(2);
//                        if (testMethod.getDescription() == null) {
//                            summaryCell.setCellValue(mthd[2]);
//                            summaryCell.setCellStyle(getTableCellStyle(workbook));
//                        } else {
//                            summaryCell.setCellValue(testMethod.getDescription());
//                            summaryCell.setCellStyle(getTableCellStyle(workbook));
//                        }
//                    }
//                }
//            });
//            // Updating failed test cases count in Summary sheet
//            XSSFCell failedCountCell = summarySheetRow.createCell(4);
//            failedCountCell.setCellValue(failedTestCount[0]);
//            failedCountCell.setCellStyle(getTableCellStyle(workbook));
//
//            //Creating Passed List Header Row//
//            rowCount[0] = rowCount[0] + 2;
//            rowCount[0] = createHeadingTextRow(workbook, moduleSheet, rowCount[0], columnCount, "Passed");
//            System.out.println("Passed Test Cases List");
//            int[] passedTestCount = {0};
//            passedTests.getAllMethods().forEach(testMethod -> {
//                for (String groupInTestMethod : testMethod.getGroups()) {
//                    if (groupInTestMethod.equals(group)) {
//                        String[] mthd = testMethod.getMethodName().split("_");
//                        System.out.println("Issue key: " + mthd[0]+ "-" +mthd[1]);
//                        System.out.println("Summary: " + mthd[2]);
//
//                        XSSFRow passedTestRow = moduleSheet.createRow(rowCount[0]++);
//                        XSSFCell indexCell = passedTestRow.createCell(0);
//                        indexCell.setCellValue(++passedTestCount[0]);
//                        indexCell.setCellStyle(getTableCellStyle(workbook));
//
//                        XSSFCell issueKeyCell = passedTestRow.createCell(1);
//                        issueKeyCell.setCellValue(mthd[0]+ "-" +mthd[1]);
//                        issueKeyCell.setCellStyle(getTableCellStyle(workbook));
//
//                        XSSFCell summaryCell = passedTestRow.createCell(2);
//                        summaryCell.setCellValue(mthd[2]);
//                        summaryCell.setCellStyle(getTableCellStyle(workbook));
//                    }
//                }
//            });
//            // Updating passed test cases count in Summary sheet //
//            XSSFCell passedCountCell = summarySheetRow.createCell(3);
//            passedCountCell.setCellValue(passedTestCount[0]);
//            passedCountCell.setCellStyle(getTableCellStyle(workbook));
//
//            //Creating Skipped List Header Row//
//            rowCount[0] = rowCount[0] + 2;
//            rowCount[0] = createHeadingTextRow(workbook, moduleSheet, rowCount[0], columnCount, "Skipped");
//            System.out.println("Skipped Test Cases List");
//            int[] skippedTestCount = {0};
//            skippedTests.getAllMethods().forEach(testMethod -> {
//                for (String groupInTestMethod : testMethod.getGroups()) {
//                    if (groupInTestMethod.equals(group)) {
//                        String[] mthd = testMethod.getMethodName().split("_");
//                        System.out.println("Issue key: " + mthd[0]+ "-" +mthd[1]);
//                        System.out.println("Summary: " + mthd[2]);
//
//                        XSSFRow skippedTestRow = moduleSheet.createRow(rowCount[0]++);
//                        XSSFCell indexCell = skippedTestRow.createCell(0);
//                        indexCell.setCellValue(++skippedTestCount[0]);
//                        indexCell.setCellStyle(getTableCellStyle(workbook));
//
//                        XSSFCell issueKeyCell = skippedTestRow.createCell(1);
//                        issueKeyCell.setCellValue(mthd[0]+ "-" +mthd[1]);
//                        issueKeyCell.setCellStyle(getTableCellStyle(workbook));
//
//                        XSSFCell summaryCell = skippedTestRow.createCell(2);
//                        summaryCell.setCellValue(mthd[2]);
//                        summaryCell.setCellStyle(getTableCellStyle(workbook));
//                    }
//                }
//            });
//            // Updating skipped test cases count in Summary sheet //
//            XSSFCell skippedCountCell = summarySheetRow.createCell(5);
//            skippedCountCell.setCellValue(skippedTestCount[0]);
//            skippedCountCell.setCellStyle(getTableCellStyle(workbook));
//
//            // Updating Total test cases count in Summary sheet //
//            XSSFCell totalCountCell = summarySheetRow.createCell(2);
//            totalCountCell.setCellValue(failedTestCount[0] + passedTestCount[0] + skippedTestCount[0]);
//            totalCountCell.setCellStyle(getTableCellStyle(workbook));
//
//        }
//        FileOutputStream outputStream = new FileOutputStream(System.getProperty("user.dir") + "//target//ExcelTestReport.xlsx");
//        workbook.write(outputStream);
//        outputStream.close();
//
//    }
//
//    private XSSFCellStyle getSummarySheetHeaderStyle(XSSFWorkbook workbook) {
//        XSSFCellStyle headerStyle = workbook.createCellStyle();
//        headerStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
//        headerStyle.setFillForegroundColor(IndexedColors.PALE_BLUE.getIndex());
//        XSSFFont headerFont = workbook.createFont();
//        headerFont.setBold(true);
//        headerStyle.setFont(headerFont);
//        headerStyle.setAlignment(HorizontalAlignment.LEFT);
//        headerStyle.setBorderBottom(BorderStyle.THIN);
//        headerStyle.setBorderLeft(BorderStyle.THIN);
//        headerStyle.setBorderRight(BorderStyle.THIN);
//        headerStyle.setBorderTop(BorderStyle.THIN);
//        return headerStyle;
//    }
//
//    //Summary Sheet - Group link style
//    private XSSFCellStyle getSummarySheetModuleLinkStyle(XSSFWorkbook workbook) {
//        XSSFCellStyle hlink_cellStyle = workbook.createCellStyle();
//        XSSFFont hlink_font = workbook.createFont();
//        hlink_font.setUnderline(XSSFFont.U_SINGLE);
//        hlink_font.setColor(IndexedColors.BLUE.getIndex());
//        hlink_cellStyle.setFont(hlink_font);
//        hlink_cellStyle.setAlignment(HorizontalAlignment.LEFT);
//        hlink_cellStyle.setBorderBottom(BorderStyle.THIN);
//        hlink_cellStyle.setBorderLeft(BorderStyle.THIN);
//        hlink_cellStyle.setBorderRight(BorderStyle.THIN);
//        hlink_cellStyle.setBorderTop(BorderStyle.THIN);
//        return hlink_cellStyle;
//    }
//
//    //Summary Sheet - Create hyperlink for Group
//    private Hyperlink getSummarySheetModuleLink(XSSFWorkbook workbook, String groupName) {
//        CreationHelper creationHelper = workbook.getCreationHelper();
//        Hyperlink link = creationHelper.createHyperlink(HyperlinkType.DOCUMENT);
//        link.setAddress(groupName + "!A1");
//        return link;
//    }
//
//    private XSSFCellStyle getModuleSheetTableHeaderStyle(XSSFWorkbook workbook) {
//        XSSFCellStyle headerStyle = workbook.createCellStyle();
//        headerStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
//        headerStyle.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
//        XSSFFont headerFont = workbook.createFont();
//        headerFont.setBold(true);
//        headerStyle.setFont(headerFont);
//        headerStyle.setAlignment(HorizontalAlignment.LEFT);
//        headerStyle.setBorderBottom(BorderStyle.THIN);
//        headerStyle.setBorderLeft(BorderStyle.THIN);
//        headerStyle.setBorderRight(BorderStyle.THIN);
//        headerStyle.setBorderTop(BorderStyle.THIN);
//        return headerStyle;
//    }
//
//    private XSSFCellStyle getTableCellStyle(XSSFWorkbook workbook) {
//        XSSFCellStyle headerStyle = workbook.createCellStyle();
//        headerStyle.setAlignment(HorizontalAlignment.LEFT);
//        headerStyle.setBorderBottom(BorderStyle.THIN);
//        headerStyle.setBorderLeft(BorderStyle.THIN);
//        headerStyle.setBorderRight(BorderStyle.THIN);
//        headerStyle.setBorderTop(BorderStyle.THIN);
//        return headerStyle;
//    }
//
//    private void createHeaderRow(XSSFWorkbook workbook, XSSFRow headerRow, int columnCount) {
//        Cell cell1 = headerRow.createCell(columnCount);
//        cell1.setCellStyle(getModuleSheetTableHeaderStyle(workbook));
//        cell1.setCellValue("S.No");
//
//        Cell cell2 = headerRow.createCell(columnCount+1);
//        cell2.setCellStyle(getModuleSheetTableHeaderStyle(workbook));
//        cell2.setCellValue("Issue key");
//
//        Cell cell3 = headerRow.createCell(columnCount+2);
//        cell3.setCellStyle(getModuleSheetTableHeaderStyle(workbook));
//        cell3.setCellValue("Summary");
//    }
//
//    private int createHeadingTextRow(XSSFWorkbook workbook, XSSFSheet sheet, int rowCount, int columnCount, String status){
//        XSSFRow headingTextRow = sheet.createRow(rowCount);
//        XSSFCell moduleCell = headingTextRow.createCell(columnCount);
//        XSSFCellStyle headerStyle = workbook.createCellStyle();
//        headerStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
//        switch (status) {
//            case "Failed":
//                headerStyle.setFillForegroundColor(IndexedColors.RED.getIndex());
//                break;
//            case "Passed":
//                headerStyle.setFillForegroundColor(IndexedColors.GREEN.getIndex());
//                break;
//            case "Skipped":
//                headerStyle.setFillForegroundColor(IndexedColors.YELLOW1.getIndex());
//                break;
//        }
//        XSSFFont headerFont = workbook.createFont();
//        headerFont.setBold(true);
//        headerStyle.setFont(headerFont);
//        headerStyle.setAlignment(HorizontalAlignment.LEFT);
//        headerStyle.setBorderBottom(BorderStyle.THIN);
//        headerStyle.setBorderLeft(BorderStyle.THIN);
//        headerStyle.setBorderRight(BorderStyle.THIN);
//        headerStyle.setBorderTop(BorderStyle.THIN);
//
//        for (int i = 0; i < 3; i++) {
//            Cell cell = headingTextRow.createCell(i);
//            cell.setCellStyle(headerStyle);
//            if (i ==0){
//                switch (status) {
//                    case "Failed":
//                        moduleCell.setCellValue("Failed Test Cases");
//                        break;
//                    case "Passed":
//                        moduleCell.setCellValue("Passed Test Cases");
//                        break;
//                    case "Skipped":
//                        moduleCell.setCellValue("Skipped Test Cases");
//                        break;
//                }
//            }
//        }
//
//        sheet.addMergedRegion(new CellRangeAddress(rowCount, rowCount, columnCount,columnCount + 2));
//        rowCount = rowCount + 1;
//        XSSFRow failedListTableHeaderRow = sheet.createRow(rowCount++);
//        createHeaderRow(workbook, failedListTableHeaderRow, columnCount);
//        return rowCount;
//    }
}
