package com.ewbc.qa.web.framework.base;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Method;
import java.security.NoSuchAlgorithmException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.ITestContext;
import org.testng.ITestResult;
import org.testng.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import org.testng.asserts.Assertion;

import com.ewbc.qa.web.framework.base.BaseException;
import com.ewbc.qa.web.framework.base.config.ConfigInput;
import com.ewbc.qa.web.framework.base.config.ConfigManger;
import com.ewbc.qa.web.framework.core.DriverManager;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.relevantcodes.extentreports.model.Log;


public class BaseTest1 {
	 private final static Logger log = Logger.getLogger(BaseTest1.class);
	protected static ExtentReports extent;
    public WebDriver driver;
    protected Assertion assertions;
    public static ExtentTest extentTest;
    private Map<String, Object> _customCapabilities;
	
	
	
	
	@BeforeSuite(alwaysRun = true)
	public void beforeSuite(ITestContext suite) throws Exception {
		// load the automation.properties file
		ConfigInput.init();
		String workingDir = System.getProperty("user.dir");
		extent = new ExtentReports(workingDir+"/target/CRM_CCR_Report.html", true);
	    extent.loadConfig(new File(workingDir+"//src/main//resources//reportconfig.xml"));
		//extent = new ExtentReports(System.getProperty("user.dir") + "/test-output/CRM_CCR_Report.html", true);
		
		// display the Environment details to the extent report Dashboard
		extent.addSystemInfo("Application URL", ConfigInput.url);
		extent.addSystemInfo("Browser", ConfigInput.browser);
	}

	@BeforeClass(alwaysRun = true)
	public void beforeClassRun() throws IOException, BaseException {

		// Initialize driver
		DriverManager.startWebSession(null);
	}

	@BeforeTest(alwaysRun = true)
	public void beforeTest() throws IOException, BaseException {
		
	}

//	@BeforeMethod(alwaysRun = true)
//		public final void mandatoryBeforeTestMethod(Method method) throws BaseException, NoSuchAlgorithmException,
//		 IOException, InterruptedException {
//		test = extent.startTest((this.getClass().getSimpleName() + " :: "+method.getName()), method.getAnnotation(Test.class).description());
//		test.log(LogStatus.INFO, "Started Test :: "+ method.getName() + " :: "+ method.getAnnotation(Test.class).description());
//		//Log.info("Started test case "+method.getName());
//		String baseUrl=null;
//		
//}
	@Parameters({"browserName"})
    @BeforeMethod(alwaysRun = true)
    public final void mandatoryBeforeTestMethod(Method testMethod, @Optional() String browserName) throws BaseException {
        extentTest = extent.startTest((this.getClass().getSimpleName() + " :: " + testMethod.getName()),
                testMethod.getAnnotation(Test.class).description());
        Reporter.log("Started Test :: " + testMethod.getName());
        log.info("Started Test :: " + testMethod.getName());
        if (browserName != null) {
            ConfigManger.overrideProperty("browser.name", browserName);
        }
        driver = DriverManager.startWebSession(testMethod);
    }

    public WebDriver getDriver() {
        return driver;
    }	
	

//	public static File getScreenshot(WebDriver driver, String screenshotName) throws IOException {
//		String dateName = new SimpleDateFormat("yyyyMMddhhmmss").format(new Date());
//		TakesScreenshot ts = (TakesScreenshot) driver;
//		File source = ts.getScreenshotAs(OutputType.FILE);
//		String destination = "./target/FailedTestsScreenshots/"+screenshotName + dateName
//				+ ".png";
//		File finalDestination = new File(destination);
//		FileUtils.copyFile(source, finalDestination);
//		return finalDestination;
//	}
	public static File getScreenshot(WebDriver driver, String screenshotName) throws IOException, Exception {
        File finalDestination = null;
        try {
            String dateName = new SimpleDateFormat("yyyyMMdd").format(new Date());
            TakesScreenshot ts = (TakesScreenshot) driver;
            File source = ts.getScreenshotAs(OutputType.FILE);
            String destination = "./target/FailedTestsScreenshots/" + screenshotName + dateName
                    + ".png";
            finalDestination = new File(destination);
            FileUtils.copyFile(source, finalDestination);
        } catch (IOException e) {
            log.error("Failed to capture screenshot due to : " + e);
            Reporter.log("Failed to capture screenshot due to : " + e);
            Reporter.log("Failed to capture screenshot due to : " + e.getStackTrace().toString());
            log.info(e.getStackTrace().toString());
        }catch(Exception e){
            log.error("Failed to capture screenshot due to : " + e);
            Reporter.log("Failed to capture screenshot due to : " + e);
            Reporter.log("Failed to capture screenshot due to : " + e.getStackTrace().toString());
            log.info(e.getStackTrace().toString());
        }
        return finalDestination;
    }
	@AfterMethod
	public void tearDown(ITestResult result,Method method) throws IOException, BaseException {
		try {
	        if (result.getStatus() == ITestResult.FAILURE) {
	            log.info(result.getName() + ":: FAILED");
	            Reporter.log(result.getName() + ":: FAILED");
	        } else if (result.getStatus() == ITestResult.SKIP) {
	            log.info(result.getName() + ":: SKIPPED");
	            Reporter.log(result.getName() + ":: SKIPPED");
	            Reporter.log(result.getThrowable() + ":: SKIPPED");
	        } else if (result.getStatus() == ITestResult.SUCCESS) {
	            log.info(result.getName() + ":: PASSED");
	            Reporter.log(result.getName() + ":: PASSED");
	        }

	        if (result.getStatus() == ITestResult.FAILURE) {
	            String filePath;
	            File screenshotPath = BaseTest.getScreenshot(DriverManager.getDriver(), result.getName());
//	            System.out.println("+++++++++++++++++++++++++++++++++++++++");
//	            System.out.println(screenshotPath.getPath());
//	            System.out.println(screenshotPath.getAbsolutePath());
//	            System.out.println("+++++++++++++++++++++++++++++++++++++++");
	            filePath = screenshotPath.getPath();
	            // if(ConfigInput.imagelocation.contains("http")) {
	            //	filePath = ConfigInput.imagelocation+screenshotPath.getPath();
	            // }else {
	            // 	filePath = screenshotPath.getAbsolutePath();
	            // }
//	            System.out.println("+++++++++++++++++++++++++++++++++++++++");
	            filePath = filePath.replace("\\target", "");
//	            System.out.println(filePath);
//	            System.out.println("+++++++++++++++++++++++++++++++++++++++");
	            extentTest.log(LogStatus.FAIL, extentTest.addScreenCapture(filePath)); // to add screenshot in extent
	            extentTest.log(LogStatus.FAIL, "TEST CASE FAILED DUE TO " + result.getThrowable()); // to add error/exception in
	            extentTest.log(LogStatus.FAIL, "TEST CASE FAILED IS " + result.getName()); // to add name in extent report														// extent report														// report
	            // extentTest.log(LogStatus.FAIL, extentTest.addScreencast(screenshotPath));  // to add screencast/video in extent report
	        } else if (result.getStatus() == ITestResult.SKIP) {
	            extentTest.log(LogStatus.SKIP, "Test Case SKIPPED IS " + result.getName());
	        } else if (result.getStatus() == ITestResult.SUCCESS) {
	            extentTest.log(LogStatus.PASS, "Test Case PASSED IS " + result.getName());
	            //if (ConfigManger.getProperty("enableScreenshotOnSuccess") != null && ConfigManger.getProperty("enableScreenshotOnSuccess").equalsIgnoreCase("true")) {
	            if  (ConfigManger.getProperty("enableScreenshotOnSuccess").equalsIgnoreCase("true")) {
	                String filePath;
	                File screenshotPath = BaseTest.getScreenshot(DriverManager.getDriver(), result.getName());
	                filePath = screenshotPath.getPath();
	                filePath = filePath.replace("\\target", "");
	                extentTest.log(LogStatus.PASS, extentTest.addScreenCapture(filePath)); // to add screenshot in extent

	            }

	        }
//	        DriverManager.killAllSessions(true);
//	        extent.endTest(extentTest);
	    }catch(Exception e){
	        log.error("Failed in BaseTest teardown : " + e);
	        Reporter.log("Failed in BaseTest teardown  : " + e);
	        Reporter.log("Failed in BaseTest teardown : " + e.getStackTrace().toString());
	        log.info(e.getStackTrace().toString());
	        Reporter.log("******************************Error while testcase teardown method*****************************************" );
//	        DriverManager.killAllSessions(true);
//	        extent.endTest(extentTest);
	    }

 
	}

	@AfterTest
	public void afterTest() {
		extent.flush();

	}

	@AfterClass(alwaysRun = true)
	public void afterClassRun() {

		DriverManager.killAllSessions(true);
		extent.endTest(extentTest);

	}

	@AfterSuite(alwaysRun = true)
	public void afterSuite() {
	}
	public void reportLog(String message) {
        message = System.lineSeparator() + message;
        Reporter.log(message);
    }

}
