package com.ewbc.qa.web.framework.utility;

/**
 * Exception class for general utils errors.
 */
public class UtilsRuntimeException extends RuntimeException {

  private static final long serialVersionUID = 1L;

  public UtilsRuntimeException(String message) {
    super(message);
  }

}
