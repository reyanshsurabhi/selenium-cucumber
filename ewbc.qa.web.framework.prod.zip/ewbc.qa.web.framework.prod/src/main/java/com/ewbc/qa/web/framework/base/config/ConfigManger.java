package com.ewbc.qa.web.framework.base.config;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.ConcurrentHashMap;

import org.openqa.selenium.Capabilities;
import org.openqa.selenium.remote.DesiredCapabilities;



public class ConfigManger {
	private static final String PROPERTIES_FILE = "/automation.properties";
	private static Properties properties = new Properties();
	protected static ConcurrentHashMap<String, String> _config = null;
	protected static Map<Long, ConcurrentHashMap<String, String>> _overridePropertiesHash = Collections
			.synchronizedMap(new LinkedHashMap<Long, ConcurrentHashMap<String, String>>());

	/**
	 * static method to get Instance of class AutProperties
	 *
	 * @return
	 */
	public ConfigManger() {
		loadProperties(getPropertiesFile());
	}

	/**
	 * Get the property as a boolean.
	 *
	 * @param name      Property name
	 * @return          true if the property is set to true, false otherwise (property is false or null)
	 */
	 /* public boolean getPropertyAsBoolean(ConfigParameters name) {
	    String property = getProperty(name);
	    if (property == null) {
	      return false;
	    }
	    return Boolean.parseBoolean(property);
	  }*/

	/**
	 * Step 1
	 *
	 * Get the Property file as input stream
	 *
	 * @return
	 */
	private InputStream getPropertiesFile() {
		// System.out.println(PROPERTIES_FILE);
		return this.getClass().getResourceAsStream(PROPERTIES_FILE);
	}

	/**
	 * Step 2
	 *
	 * Load Properties
	 *
	 * @param propertiesStream
	 * @return
	 */
	private void loadProperties(InputStream propertiesStream) {
		try {
			properties.load(propertiesStream);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static String getProperty(String key) {
		return properties.getProperty(key);
	}

	public String getProperty(String key, String defaultValue) {
		return properties.getProperty(key, defaultValue);
	}

	public void setProperty(String key, String value) {
		properties.setProperty(key, value);
	}

	public Capabilities getCaps() throws IOException {
//		String capabilitiesFile = properties.getProperty("capabilities");
		String browserType = getProperty("browser.name");
		String capabilitiesFile;
		switch (browserType) {
			case "firefox":
				capabilitiesFile = "/firefox.capabilities";
				break;
			case "chrome":
				capabilitiesFile = "/chrome.capabilities";
				break;
			case "iexplore":
				capabilitiesFile = "/iexplore.capabilities";
				break;
			default:
				capabilitiesFile = "/chrome.capabilities";
		}
		Properties capsProps = new Properties();
		capsProps.load(ConfigManger.class.getResourceAsStream(capabilitiesFile));

		DesiredCapabilities capabilities = new DesiredCapabilities();
		for (String name : capsProps.stringPropertyNames()) {
			String value = capsProps.getProperty(name);
			if (value.toLowerCase().equals("true") || value.toLowerCase().equals("false")) {
				capabilities.setCapability(name, Boolean.valueOf(value));
			} else if (value.startsWith("file:")) {
				capabilities.setCapability(name,
						new File(".", value.substring(5)).getCanonicalFile().getAbsolutePath());
			} else {
				capabilities.setCapability(name, value);
			}
		}

		return capabilities;
	}

	public boolean hasProperty(String name) {
		return properties.contains(name);
	}

	public static void overrideProperty(String propertyName, String propertyValue) {
		 properties.remove(propertyName);
		 properties.setProperty(propertyName, propertyValue);
	}

}
