package com.ewbc.qa.web.framework.utility;


import io.qameta.allure.Attachment;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriverException;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

import com.ewbc.qa.web.framework.core.DriverManager;
import com.ewbc.qa.web.framework.base.BaseException;

public class TestListener implements ITestListener {

    @Override
    public void onTestStart(ITestResult iTestResult) {

    }

    @Override
    public void onTestSuccess(ITestResult iTestResult) {

    }

    @Override
    public void onTestFailure(ITestResult tr) {
//        try {
//			if (DriverManager.getDriver() != null) {
//			    captureScreenshot();
//			}
//		} catch (BaseException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
    }

    @Override
    public void onTestSkipped(ITestResult iTestResult) {

    }

    @Override
    public void onTestFailedButWithinSuccessPercentage(ITestResult iTestResult) {

    }

    @Override
    public void onStart(ITestContext iTestContext) {

    }

    @Override
    public void onFinish(ITestContext iTestContext) {

    }

//    @Attachment(value = "Failure Screenshot", type = "image/png")
//    private byte[] captureScreenshot() throws WebDriverException, BaseException {
//        String fileName = "Failure Screenshot";
//        String type = "image/png";
//        return ((TakesScreenshot) DriverManager.getDriver()).getScreenshotAs(OutputType.BYTES);
//    }
}