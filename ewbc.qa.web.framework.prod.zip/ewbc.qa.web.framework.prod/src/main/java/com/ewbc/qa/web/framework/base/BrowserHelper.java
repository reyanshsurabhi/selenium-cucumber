package com.ewbc.qa.web.framework.base;

import com.ewbc.qa.web.framework.base.config.ConfigManger;
import com.ewbc.qa.web.framework.core.DriverManager;
import org.apache.log4j.Logger;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.*;
import org.testng.Assert;

import java.io.IOException;
import java.lang.Integer;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.*;
import java.util.concurrent.TimeUnit;


public class BrowserHelper {

    public final static Logger log = Logger.getLogger(BrowserHelper.class.getName());
    private WebDriver driver;
    protected static WebDriverWait wait;
    public static int WAITTIME = (ConfigManger.getProperty("explicitWaitTime") != null) ? Integer.parseInt(ConfigManger.getProperty("explicitWaitTime")) : 30;

    public BrowserHelper() throws IOException, BaseException {
        	log.info("Explicit Wait Time: " + WAITTIME);
    }

    /**
     * clears the text in the element
     *
     * @param driver
     * @param elem
     */
    public static void clearElement(WebDriver driver, WebElement elem) {
        WebElement element = waitForElementLocated(driver, elem);
        element.clear();
    }

    /**
     * Maximizes the window
     *
     * @throws Exception
     */

    @SuppressWarnings("unchecked")
    public void maximizeWindow() throws Exception {
        String script = "return [window.screen.availWidth, window.screen.availHeight];";
        List<Long> dimensions = (List<Long>) getJavascriptExecutor().executeScript(script);
        resizeWindow(dimensions.get(0).intValue(), dimensions.get(1).intValue());
    }

    /**
     * Indicates that a driver can execute JavaScript, providing access to the mechanism to do so
     *
     * @return js    Returns JavascriptExecutor for executing js.
     * @throws Exception
     */
    public JavascriptExecutor getJavascriptExecutor() throws Exception {
        JavascriptExecutor js = null;
        if (getDriver() instanceof JavascriptExecutor) {
            js = (JavascriptExecutor) getDriver();
        }
        return js;
    }

    /**
     * Sets window size
     *
     * @param width  Window width
     * @param height Window length
     * @throws Exception
     */
    public void resizeWindow(int width, int height) throws Exception {
        // Resize browser window for mobile web
        getDriver().manage().window().setPosition(new Point(0, 0));
        getDriver().manage().window().setSize(new Dimension(width, height));
    }

    protected WebDriver getDriver() throws Exception {
        try {
            return driver != null ? driver : DriverManager.getDriver();
        } catch (BaseException e) {
            throw new Exception("Error getting driver: " + e.getMessage());
        }
    }

    /**
     * This method will click on webElement
     *
     * @param driver
     * @param elem
     */
    public static void clickOnElement(WebDriver driver, WebElement elem) throws Exception {

        WebElement element = waitForElementLocated(driver, elem);
        element.click();

    }

    /**
     * This method will click on webElement 'elem' and wait for invisibility of 'invElem'
     *
     * @param driver
     * @param elem
     * @param invElemLocator
     */
    public static void clickOnElementAndWaitForElemInvisiblity(WebDriver driver, WebElement elem, By invElemLocator) {
    	wait = new WebDriverWait(driver, WAITTIME);
        WebElement element = waitForElementLocated(driver, elem);
        element.click();
        waitForElementNotToBeVisible(driver, invElemLocator);
    }
    
    /**
     * This method will clear a textbox and enter text to the textbox
     *
     * @param driver
     * @param elem
     * @param string
     */
    public static void clearAndEnterText(WebDriver driver, WebElement elem, String string) {
        waitForElementVisible(driver, elem);
        elem.clear();
        sleep(2);
        elem.sendKeys(string);
    }

    /**
     * This method will enters the textbox without clearing it
     *
     * @param driver
     * @param elem
     * @param string
     */
    public static void enterText(WebDriver driver, WebElement elem, String string) {
        waitForElementVisible(driver, elem);
        sleep(2);
        elem.sendKeys(string);
    }

    /**
     * @param driver
     * @param milliseconds
     * @throws Exception
     */
    public static void waitForAngularPageToLoad(WebDriver driver, long milliseconds) throws Exception {
        wait = new WebDriverWait(driver, 10, 100);
        sleep((int) milliseconds / 1000);
    }

    /**
     * This method will clear a textbox and enter text to the textbox
     *
     * @param driver
     * @param elem
     * @param string
     * @throws Exception
     */
    public static void clearAndTypeText(WebDriver driver, WebElement elem, String string) throws Exception {
        waitForElementVisible(driver, elem);
        elem.clear();
        for (int i = 0; i < string.length(); i++) {
            elem.sendKeys(Character.toString(string.charAt(i)));
            Thread.sleep(1000);
        }
    }

    /**
     * check if element is present
     *
     * @param driver
     * @param elem
     * @return
     */
    public static boolean isElementPresent(WebDriver driver, WebElement elem) {
        try {
            log.info("Verifying element with path " + elem + " is present or not");
            if (elem.isDisplayed())
                ;
            return true;
        } catch (Exception e) {
            log.error("Element is not present with path " + elem);
            return false;
        }
    }
    /**
     * check if element is present
     *
     * @param driver
     * @param elem
     * @param timeOutSecs
     * @return
     */
    public static boolean isElementPresent(WebDriver driver, WebElement elem, int timeOutSecs) {
        try {
            log.info("Verifying element with path " + elem + " is present or not");
            wait = new WebDriverWait(driver, timeOutSecs);
            wait.until(ExpectedConditions.visibilityOf(elem));
            return true;
        } catch (Exception e) {
            log.info("Element is not present with path " + elem);
            log.info(e.getMessage());
            return false;
        }
    }

    /**
     * check if element is present
     *
     * @param elem
     * @return
     */
    public static boolean isElementPresent(WebElement elem) {
        try {
            log.info("Verifying element with path " + elem + " is present or not");
            if (elem.isDisplayed())
                ;
            return true;
        } catch (Exception e) {
            log.error("Element is not present with path " + elem);
            return false;
        }
    }

    /**
     * Checks if alert is present
     *
     * @param driver
     * @return
     */
    public static boolean isAlertPresent(WebDriver driver) {
        try {
            driver.switchTo().alert();
            return true;
        } catch (NoAlertPresentException e) {
            log.error("Alert is not present");
            return false;
        }
    }

    /**
     * Select from drop down elem value
     *
     * @param driver
     * @param elem
     * @param valueToBeSelected
     */

    public static void selectelemValue(WebDriver driver, WebElement elem, String valueToBeSelected) {
        try {
            WebElement element = waitForElementLocated(driver, elem);
            Select select = new Select(element);
            select.selectByValue(valueToBeSelected);
            waitForAngularPageToLoad(driver, 3000);

        } catch (Exception e) {
            log.error("Error while selecting elem value " + e);
        }
    }

    /**
     * Returns the selected value
     *
     * @param driver
     * @param elem
     * @param valueToBeSelected
     */
    public static String getSelectedValue(WebDriver driver, WebElement elem) {
        try {
            WebElement element = waitForElementLocated(driver, elem);
            Select select = new Select(element);
            return select.getAllSelectedOptions().get(0).getText();

        } catch (Exception e) {
            log.error("Error while selecting elem value " + e);
            return "";
        }
    }

    /**
     * This method selects the option elem its visible text
     *
     * @param driver
     * @param elem
     * @param valueToBeSelected
     */
    public static void selectelemVisibleText(WebDriver driver, WebElement elem, String valueToBeSelected) {
        try {
            WebElement element = waitForElementLocated(driver, elem);
            Select select = new Select(element);
            select.selectByVisibleText(valueToBeSelected);
            waitForAngularPageToLoad(driver, 3000);
        } catch (Exception e) {
            log.error("Error while seleting elem visible text" + e);
        }
    }

    /**
     * This method will help to select the option elem its index
     *
     * @param driver
     * @param elem
     * @param index
     */
    public static void selectelemIndex(WebDriver driver, WebElement elem, int index) {
        try {
            WebElement element = waitForElementLocated(driver, elem);
            Select select = new Select(element);
            select.selectByIndex(index);
            waitForAngularPageToLoad(driver, 3000);
        } catch (Exception e) {
            log.error(e);

        }
    }

    /**
     * This method will return the attribute value of the locator
     *
     * @param driver
     * @param elem
     * @param attribute
     * @return
     * @throws CustomException
     */
    public static String getAttributeValue(WebDriver driver, WebElement elem, String attribute) throws Exception {
        try {
            WebElement element = waitForElementLocated(driver, elem);
            return element.getAttribute(attribute);

        } catch (Exception e) {
            log.error(e);
            throw new Exception("No locator " + elem + " found");
        }

    }

    /**
     * This method will return all the option values present in the select box
     *
     * @param driver
     * @param elem
     * @return
     * @throws Exception
     */
    public static ArrayList<String> getAllValuesOfSelect(WebDriver driver, WebElement elem) throws Exception {
        ArrayList<String> values = new ArrayList<String>();
        Select select = new Select(elem);
        List<WebElement> optionSelect = select.getOptions();

        for (int i = 0; i < optionSelect.size(); i++) {
            values.add(optionSelect.get(i).getText().trim());
        }
        return values;
    }

    /**
     * Switches to parent frame
     *
     * @param driver
     */
    public static void switchToParentFrame(WebDriver driver) {
        try {
            driver.switchTo().parentFrame();
            waitForAngularPageToLoad(driver, 1000);
        } catch (Exception e) {
            log.error("Exception in switching to parent frame " + e);
        }
    }

    /**
     * This method will switch to frame
     *
     * @param driver
     * @param elem
     */
    public static void switchToFrame(WebDriver driver, WebElement elem) {
        WebElement frameElement = waitForElementLocated(driver, elem);
        try {
            driver.switchTo().frame(frameElement);

            waitForAngularPageToLoad(driver, 2000);
        } catch (Exception e) {
            log.error("Error while switching the frame" + e);
        }
    }

    /**
     * This method will switch to frame by using framename
     *
     * @param driver
     * @param elem
     */
    public static void waitForFrameAndSwitchToIt(WebDriver driver, String framename) {
        driver.switchTo().defaultContent();
        wait = new WebDriverWait(driver, WAITTIME);
        wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(framename));
    }

    /**
     * This method will switch to frame by using frame Element
     *
     * @param driver
     * @param elem
     */
    public static void waitForFrameAndSwitchToIt(WebDriver driver) {
        driver.switchTo().defaultContent();

        wait = new WebDriverWait(driver, WAITTIME);
        wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(By.tagName("iframe")));
    }

    /**
     * Switch to default content of web page
     *
     * @param driver
     * @throws Exception
     */
    public static void switchToFrame_byName(String framename, WebDriver driver) {

        driver.switchTo().frame(framename);

        try {
            waitForAngularPageToLoad(driver, 1000);
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    /**
     * To get all the links
     *
     * @param driver
     */

    public static void getAllLinks(WebDriver driver) {

        List<WebElement> links = driver.findElements(By.tagName("a"));
        int linkcount = links.size();
        System.out.println(links.size());
        for (WebElement myElement : links) {
            String link = myElement.getText();
            System.out.println(link + "Navigation Link exist");
            // System.out.println(myElement);
        }

    }

    /**
     * Switch to default content of web page
     *
     * @param driver
     */
    public static void switchToDefaultContent(WebDriver driver) {
        try {
            driver.switchTo().defaultContent();

            waitForAngularPageToLoad(driver, 1000);
        } catch (Exception e) {
            log.error("Error while switching to default content " + e);
        }
    }

    /**
     * Get text for a web element
     *
     * @param driver
     * @param elem
     * @return
     */
    public static String getText(WebDriver driver, WebElement elem) {
        try {
            WebElement element = waitForElementLocated(driver, elem);
            return element.getText().trim();

        } catch (Exception e) {
            log.error("Locator not found" + e);
            return null;
        }

    }

    /**
     * Get parent window handles
     *
     * @param driver
     * @return
     */
    public static String getParentWindowHandle(WebDriver driver) {
        return driver.getWindowHandle();
    }

    /**
     * Opens the link in a new window
     *
     * @param link Link to be opened in new window
     * @throws HelperException
     */
    public void openLinkInNewWindow(String link, WebDriver driver) {
        JavascriptExecutor js = getJavascriptExecutor(driver);
        String jsScript = String.format("window.open('%s')", link);
        js.executeScript(jsScript);
        switchToLastWindow(driver, false);
    }

    /**
     * Switches to the last window
     *
     * @param refresh Refresh the window if set to true
     * @throws HelperException
     */
    public void switchToLastWindow(WebDriver driver, boolean refresh) {
        String[] windowHandles = driver.getWindowHandles().toArray(new String[0]);
        driver.switchTo().window(windowHandles[windowHandles.length - 1]);
        if (refresh) {
            refresh(driver);
        }
    }

    /**
     * Switches to the window with the given title
     *
     * @param title
     * @return match Return true if the switch was successful or false
     * @throws HelperException
     */
    public boolean switchToWindowWithTitle(String title, boolean reload, WebDriver driver) {
        String currentTitle = "";
        String[] windowHandles = driver.getWindowHandles().toArray(new String[0]);
        boolean match = false;
        for (String s : windowHandles) {
            driver.switchTo().window(s);
            if (reload) {
                refresh(driver);
            }
            currentTitle = driver.getTitle();
            if (currentTitle.equals(title)) {
                // logger.info("window is switched successfully to title " + currentTitle);
                match = true;
                break;
            }
        }
        return match;
    }

    /**
     * switches to the first window
     *
     * @throws HelperException If the window cannot be found
     */
    public static void switchToParentWindow(WebDriver driver) {

        String[] windowHandles = driver.getWindowHandles().toArray(new String[0]);
        driver.switchTo().window(windowHandles[0]);
    }

    /**
     * Return count of all open windows
     *
     * @return count Count of all open windows
     */
    public int getWindowCount(WebDriver driver) {
        int count = driver.getWindowHandles().toArray(new String[0]).length;
        return count;
    }

    /**
     * Checks if there is new pop up present
     *
     * @param expectedCount new window expectedCount after the pop up is opened
     * @return
     */
    public boolean isPopUpPresent(int expectedCount, WebDriver driver) {
        boolean isPresent = false;
        int actualWindowCount = getWindowCount(driver);
        if (actualWindowCount > expectedCount) {
            isPresent = true;
        }
        return isPresent;
    }

    /**
     * get child window handles
     *
     * @param driver
     * @return
     */
    public static Set<String> getChildwindowHandles(WebDriver driver) {
        return driver.getWindowHandles();
    }

    /**
     * Switch to first child window
     *
     * @param driver
     * @return
     */
    public static void switchToFirstNewWindow(WebDriver driver) {
        Set<String> handles = driver.getWindowHandles();
        Iterator<String> it = handles.iterator();
        String parentWindow = it.next();
        String childWindow = it.next();

        driver.switchTo().window(childWindow);
    }

    /**
     * Switch to first child window
     *
     * @param driver
     * @return
     */
    public static void switchParentWindow(WebDriver driver) {
        Set<String> handles = driver.getWindowHandles();
        Iterator<String> it = handles.iterator();
        String parentWindow = it.next();
        String childWindow = it.next();

        driver.switchTo().window(parentWindow);
    }

    /**
     * Switch to second child window
     *
     * @param driver
     * @return
     */
    public static void switchToSecondNewWindow(WebDriver driver) {
        Set<String> handles = driver.getWindowHandles();
        Iterator<String> it = handles.iterator();
        String parentWindow = it.next();
        String childWindow = it.next();
        String childWindow1 = it.next();

        driver.switchTo().window(childWindow1);
    }

    /**
     * Switch to second child window
     *
     * @param driver
     * @return
     */
    public static void switchToThirdNewWindow(WebDriver driver) {
        Set<String> handles = driver.getWindowHandles();
        Iterator<String> it = handles.iterator();
        String parentWindow = it.next();
        String childWindow = it.next();
        String childWindow1 = it.next();
        String childWindow2 = it.next();
        driver.switchTo().window(childWindow2);
    }

    /**
     * Focuses on the current selected window
     */
    public void focusWindow(WebDriver driver) {
        JavascriptExecutor js = getJavascriptExecutor(driver);
        js.executeScript("window.focus(); ");
    }

    /**
     * Enter text and select from drop down
     *
     * @param driver
     * @param elem
     * @param string
     * @throws Exception
     */
    public static void enterTextAndSelectDropDownValue(WebDriver driver, WebElement elem, String string) {
        WebElement element = waitForElementLocated(driver, elem);
        try {
            element.clear();
            element.sendKeys(string);
            explicitWait(2000);
            element.sendKeys(Keys.ARROW_DOWN);
            explicitWait(2000);
            element.sendKeys(Keys.RETURN);
        } catch (Exception e) {
            log.error("Error in enterTextAndSelectDropDownValue method" + e);

        }
    }

    /**
     * Clicks using javascript executor
     *
     * @param driver
     * @param elem
     * @throws Exception
     */
    public static void jsClick(WebDriver driver, WebElement elem) throws Exception {
        try {
            log.info("Clicking on element using jsClick");
            WebElement element = waitForElementLocated(driver, elem);
            JavascriptExecutor executor = (JavascriptExecutor) driver;
            executor.executeScript("arguments[0].click();", element);
            waitForAngularPageToLoad(driver, 3000);
        } catch (Exception e) {
            log.error("Error in jsClick" + e);
            throw new Exception(e.getStackTrace().toString());
        }

    }

    /**
     * This method will return the text of selected from select box
     *
     * @param driver
     * @param elem
     * @return
     * @throws Exception
     */
    public String getSelectedOptionText(WebDriver driver, WebElement elem) throws Exception {
        Select select = new Select(elem);
        return select.getFirstSelectedOption().getText();
    }

    /**
     * This method will return the date in specified format Example format::
     * "dd-MM-yyyy"
     *
     * @param format
     * @return
     * @throws Exception
     */
    public static String getDate(String format) throws Exception {
        SimpleDateFormat sdf = new SimpleDateFormat(format);
        String date = sdf.format(new Date());
        log.info("Date is =====" + date);
        return date;
    }

    /**
     * This method will return if the check box or radio button is selected
     *
     * @param driver
     * @param elem
     * @return
     */
    public static boolean isSelected(WebDriver driver, WebElement elem) {
        try {
            WebElement element = waitForElementLocated(driver, elem);
            return element.isSelected();
        } catch (Exception e) {
            log.info(String.format("Element not  found %s", elem.toString()));
            log.info(e.getStackTrace().toString());
            return false;
        }
    }

    /**
     * This method will return if the locator is enabled
     *
     * @param driver
     * @param elem
     * @return
     */
    public static boolean isEnabled(WebDriver driver, WebElement elem) {
        try {
            WebElement element = waitForElementLocated(driver, elem);
            return element.isEnabled();
        } catch (Exception e) {
            log.info(String.format("Element not  found %s", elem.toString()));
            log.info(e.getStackTrace().toString());
            return false;
        }
    }

    /**
     * @param driver
     * @param string
     * @return
     */
    public static boolean isTextPresent(WebDriver driver, String string) {
        try {
            driver.getPageSource().contains(string);
            return true;
        } catch (NoSuchElementException e) {
            return false;
        }

    }

    /**
     * @param driver
     * @param elem
     * @return
     */
    public static int getSize(WebDriver driver, WebElement elem) {
        return driver.findElements((By) elem).size();
    }

    /**
     * @param driver
     * @param elem
     * @return
     */
    public static String getValue(WebDriver driver, WebElement elem) {
        try {
            WebElement element = waitForElementLocated(driver, elem);
            return element.getAttribute("value");
        } catch (Exception e) {
            log.error("Locator not found" + e);
            return null;
        }
    }

    /**
     * @param driver
     * @param elem
     * @return
     */
    public static String getTitle(WebDriver driver, WebElement elem) {
        try {
            WebElement element = waitForElementLocated(driver, elem);
            return element.getAttribute("title");
        } catch (Exception e) {
            log.error("Locator not found" + e);
            return null;
        }
    }

    /**
     * @param driver
     * @param elem
     * @param property
     * @return
     */
    public static String getCssValue(WebDriver driver, WebElement elem, String property) {
        try {
            WebElement element = waitForElementLocated(driver, elem);
            return element.getCssValue(property);
        } catch (Exception e) {
            log.error("Locator not found" + e);
            return null;
        }
    }

    /**
     * get child window handles
     *
     * @param driver
     * @return
     */
    public static ArrayList<String> getAllwindows(WebDriver driver) {
        ArrayList<String> list = new ArrayList<String>();
        Set<String> windows = driver.getWindowHandles();
        for (String currentTab : windows) {
            list.add(currentTab);
        }
        return list;
    }

    /**
     * @param driver
     * @param elem
     */
    public static void actionClick(WebDriver driver, WebElement elem) {
        try {
            Actions action = new Actions(driver);
            action.click(elem).build().perform();
        } catch (Exception e) {
            log.error("Error while clicking on element using action class on element " + elem + e);
        }
    }

    /**
     * @param driver
     * @param elem
     */
    public static void actionEnterValue(WebDriver driver, WebElement elem, String value) {
        try {
            Actions action = new Actions(driver);
            action.sendKeys(elem, value).build().perform();
        } catch (Exception e) {
            log.error("Error while clicking on element using action class on element " + elem + e);
        }
    }

    /**
     * @param driver
     * @param elem
     */
    public static void actionDoubleClick(WebDriver driver, WebElement elem) {
        try {
            Actions action = new Actions(driver);
            action.moveToElement(elem).doubleClick().build().perform();
        } catch (Exception e) {
            log.error("Error while clicking on element using action class on element " + elem + e);
        }
    }

    /**
     * @param driver
     * @param elem
     */
    public static void moveToElement(WebDriver driver, WebElement elem) {
        try {
            Actions action = new Actions(driver);
            action.moveToElement(elem).build().perform();
        } catch (Exception e) {
            log.error("Error while moving to element using action class " + elem + e);
        }
    }

    /**
     * @param driver
     * @param elem
     * @param message
     */
    public static void verifyText(WebDriver driver, WebElement elem, String message) {
        String actualText = getText(driver, elem);
        System.out.println("Expected Text:" + message);
        System.out.println("Actual Text:" + actualText);
        Assert.assertTrue(actualText.trim().equalsIgnoreCase(message));

    }

    /**
     * @param driver
     * @param elem
     * @param message
     * @param property
     * @throws Exception
     */
    public static void verifyText(WebDriver driver, WebElement elem, String message, String property) throws Exception {
        waitForElementVisible(driver, elem);
        String actualText = "";
        actualText = getAttributeValue(driver, elem, property);
        System.out.println("Expected Text:" + message);
        System.out.println("Actual Text:" + actualText);
        Assert.assertTrue(actualText.equalsIgnoreCase(message));
    }

    /**
     * @param length
     * @return
     */
    public static String generateRandomNumber(int length) {
        Random ran = new Random();
        StringBuilder sb = new StringBuilder(length);
        for (int i = 0; i < length; i++)
            sb.append((char) ('0' + ran.nextInt(10)));
        return sb.toString();
    }

    /**
     * Method to get yesterday's date
     *
     * @return
     */
    private static Date yesterday() {
        final Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DATE, -1);
        return cal.getTime();
    }

    /**
     * Explicit wait method to wait for the element to be visible
     *
     * @param driver
     * @param elem
     * @return an instance of WebElement
     */
    public static void waitForElementVisible(WebDriver driver, WebElement elem) {
        wait = new WebDriverWait(driver, WAITTIME);
        wait.until(ExpectedConditions.visibilityOf(elem));
    }

    public static String getCurrentTime() {
        DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date today = Calendar.getInstance().getTime();
        return df.format(today);
    }

    /**
     * Explicit wait method to wait for the element to be visible
     *
     * @param driver
     * @param by
     * @return an instance of WebElement
     */
    public static void waitForElementToBeVisible(WebDriver driver, WebElement elem) {
        wait = new WebDriverWait(driver, WAITTIME);
        wait.until(ExpectedConditions.visibilityOf(elem));
    }

    public static void waitForElementToBeVisible(WebDriver driver, WebElement elem, int seconds) {
        wait = new WebDriverWait(driver, seconds);
        wait.until(ExpectedConditions.visibilityOf(elem));
    }

    /**
     * Explicit wait method to wait for the element not to be visible
     *
     * @param driver
     * @param by
     */
    public static void waitForElementNotToBeVisible(WebDriver driver, By elem) {
        wait = new WebDriverWait(driver, WAITTIME);
        wait.until(ExpectedConditions.invisibilityOfElementLocated(elem));
    }

    /**
     * Explicit wait method to wait for the element not to be visible
     *
     * @param driver
     * @param by
     * @param seconds
     */
    public static void waitForElementNotToBeVisible(WebDriver driver, By elem, int seconds) {
        wait = new WebDriverWait(driver, seconds);
        wait.until(ExpectedConditions.invisibilityOfElementLocated(elem));
    }

    /**
     * Explicit wait method to wait for the element not to be visible.
     * Suggested to avoid this method as this method does not catch TimeoutException. (Selenium Implementation)
     *
     * @param driver
     * @param elem
     */
    public static void waitForElementNotToBeVisible(WebDriver driver, WebElement elem) {
        wait = new WebDriverWait(driver, WAITTIME);
        wait.until(ExpectedConditions.invisibilityOf(elem));
    }

    /**
     * Explicit wait method to wait for the element not to be visible
     *
     * @param driver
     * @param elem
     * @param seconds
     */
    public static void waitForElementNotToBeVisible(WebDriver driver, WebElement elem, int seconds) {
        wait = new WebDriverWait(driver, seconds);
        wait.until(ExpectedConditions.invisibilityOf(elem));
    }

    /**
     * @param waitTime
     */
    public static void explicitWait(int waitTime) {
        try {
            Thread.sleep(waitTime);
        } catch (Exception e) {
            // Log.error("Error in explicitWait method" + e);
        }
    }

    /**
     * Explicit wait method to wait for the element to be visible
     *
     * @param driver
     * @param by
     * @return an instance of WebElement
     */
    public static void waitForElementVisible(WebDriver driver, WebElement elem, int seconds) {
        wait = new WebDriverWait(driver, seconds);
        wait.until(ExpectedConditions.visibilityOfElementLocated((By) elem));
    }

    /**
     * Explicit wait method to wait for the element to be click-able
     *
     * @param driver
     * @param by
     * @return an instance of WebElement
     */
    public static void waitForElementClickable(WebDriver driver, WebElement elem) {
        wait = new WebDriverWait(driver, WAITTIME);
        wait.until(ExpectedConditions.elementToBeClickable(elem));
    }

    /**
     * @param driver
     * @param by
     * @param seconds
     */
    public static void waitForElementClickable(WebDriver driver, WebElement elem, int seconds) {
        wait = new WebDriverWait(driver, seconds);
        wait.until(ExpectedConditions.elementToBeClickable(elem));
    }

    /**
     * @param driver
     * @param by
     * @return
     */
    public static boolean waitForElementSelectable(WebDriver driver, WebElement elem) {
        wait = new WebDriverWait(driver, WAITTIME);
        return wait.until(ExpectedConditions.elementToBeSelected(elem));
    }

    /**
     * Explicit wait method to wait for the text to be visible
     *
     * @param driver
     * @param by
     * @param text
     * @return
     */
    public static boolean waitForTextToBe(WebDriver driver, WebElement elem, String text) {
        wait = new WebDriverWait(driver, WAITTIME);
        return wait.until(ExpectedConditions.textToBe((By) elem, text));
    }

    /**
     * Explicit wait method to wait for the element to be located at the provided
     * locator
     *
     * @param driver
     * @param elem
     * @return an instance of WebElement
     */
    public static WebElement waitForElementLocated(WebDriver driver, WebElement elem) {
        wait = new WebDriverWait(driver, WAITTIME);
        return wait.until(ExpectedConditions.visibilityOf(elem));
    }

    /**
     * Explicit wait method to wait for the element to be visible within 5sec
     *
     * @param driver
     * @param by
     * @return an instance of WebElement
     */
    public static WebElement waitForElementVisibleWithin5sec(WebDriver driver, WebElement elem) {
        wait = new WebDriverWait(driver, 5);
        return wait.until(ExpectedConditions.visibilityOfElementLocated((By) elem));
    }

    /**
     * returns an instance on by class
     *
     * @param locatorType
     * @param locatorValue
     * @return
     * @throws CustomException
     */
    public By getInstanceOfByClassBasedOnTypeOfLocator(String locatorType, String locatorValue) throws Exception {
        // Return a instance of By class based on type of locator
        switch (locatorType) {
            case "id":
                return By.id(locatorValue);
            case "name":
                return By.name(locatorValue);
            case "classname":
                return By.className(locatorValue);
            case "class":
                return By.className(locatorValue);
            case "tagname":
                return By.tagName(locatorValue);
            case "tag":
                return By.tagName(locatorValue);
            case "linktext":
                return By.linkText(locatorValue);
            case "link":
                return By.linkText(locatorValue);
            case "partiallinktext":
                return By.partialLinkText(locatorValue);
            case "cssselector":
                return By.cssSelector(locatorValue);
            case "css":
                return By.cssSelector(locatorValue);
            case "xpath":
                return By.xpath(locatorValue);
            default:
                throw new Exception("Locator type '" + locatorType + "' not defined!!");
        }
    }

    public static void waitForAllElement(WebDriver driver, WebElement element, By sub_locator) throws Exception {
        WebDriverWait wait = new WebDriverWait(driver, 15, 100);
        wait.until(ExpectedConditions.visibilityOfNestedElementsLocatedBy(element, sub_locator));

    }

    /**
     * @param durationInSeconds
     */
    public static void sleep(int durationInSeconds) {
        try {
//			Sleeper.SYSTEM_SLEEPER.sleep(new Duration(durationInSeconds, TimeUnit.SECONDS));
            Sleeper.SYSTEM_SLEEPER.sleep(Duration.ofSeconds(durationInSeconds));
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }

    public void waitForPageToLoad(WebDriver driver) {

        ExpectedCondition<Boolean> expectation = new ExpectedCondition<Boolean>() {
            public Boolean apply(WebDriver driver) {
                return ((JavascriptExecutor) driver).executeScript("return document.readyState").equals("complete");
            }
        };
        Wait<WebDriver> wait = new WebDriverWait(driver, 10);
        try {
            wait.until(expectation);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public boolean isElementDisplayed(String XPath, WebDriver driver) {
        if (driver.findElements(By.xpath(XPath)).size() > 0) {
            return true;
        }
        return false;
    }

    /**
     * Refresh the current page
     */
    public static void refresh(WebDriver driver) {
        driver.navigate().refresh();
    }

    /**
     * Move back a single "item" in the browser's history.
     */
    public static void goBack(WebDriver driver) {
        driver.navigate().back();
    }

    /**
     * Close the current window, quitting the browser if it's the last window
     * currently open.
     */
    public static void close(WebDriver driver) {
        driver.close();
    }

    public void open(String link, WebDriver driver) {
        driver.get(link);
        waitForPageToLoad(driver);
    }

    public boolean isPageLoaded(WebDriver driver) {
        boolean pageLoad = false;
        JavascriptExecutor js = getJavascriptExecutor(driver);
        String pageState = (String) js.executeScript("return document.readyState;");
        if (pageState.equals("complete")) {
            pageLoad = true;
        }
        return pageLoad;
    }

    /**
     * Indicates that a driver can execute JavaScript, providing access to the
     * mechanism to do so
     *
     * @return js Returns JavascriptExecutor for executing js.
     */
    public JavascriptExecutor getJavascriptExecutor(WebDriver driver) {
        JavascriptExecutor js = null;
        if (driver instanceof JavascriptExecutor) {
            js = (JavascriptExecutor) driver;
        }
        return js;
    }

    /**
     * Clicks using javascript executor
     *
     * @param driver
     * @param elem
     * @throws Exception
     */
    public static void jsScrollIntoView(WebDriver driver, WebElement elem) throws Exception {
        try {
            log.info("Scroll element using java script");
            WebElement element = waitForElementLocated(driver, elem);
            JavascriptExecutor executor = (JavascriptExecutor) driver;
            executor.executeScript("arguments[0].scrollIntoView(false);", element);
            waitForAngularPageToLoad(driver, 3000);
        } catch (Exception e) {
            log.error("Error in jsClick" + e);
            throw new Exception(e.getStackTrace().toString());
        }
    }

    /**
     * This method will click on webElement
     *
     * @param driver
     * @param by (element locator)
     */
    public static void clickOnElement(WebDriver driver, By by) throws Exception {
        WebElement element = waitForElementLocated(driver, driver.findElement(by));
        element.click();
    }

}
