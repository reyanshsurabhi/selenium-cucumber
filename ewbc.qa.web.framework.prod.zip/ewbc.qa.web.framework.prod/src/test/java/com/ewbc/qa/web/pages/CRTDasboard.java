package com.ewbc.qa.web.pages;

import static org.testng.Assert.assertNotEquals;
import static org.testng.Assert.assertTrue;

import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.IOException;

import org.apache.commons.lang3.RandomStringUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.testng.Assert;
import org.testng.Reporter;

import com.ewbc.qa.web.framework.base.BasePage;
import com.ewbc.qa.web.framework.base.BrowserHelper;
import com.ewbc.qa.web.framework.base.BaseException;

public class CRTDasboard extends BasePage {
	public final static Logger log = Logger.getLogger(CRTDasboard.class.getName());
	WebDriver driver;
	private static WebElement element = null;

	public CRTDasboard(WebDriver driver) throws IOException, BaseException {
		super(driver);
		this.driver = driver;
	}

	@FindBy(id = "CRT")
	WebElement clickOnNewCRTlink;
	
	@FindBy(id = "homeButtonImage")
	WebElement clickOnhomeButtonImage;
	

	@FindBy(id = "nav_dashboards")
	WebElement navdashboards;
	
	@FindBy(id = "dashboardSelectorContainer")
	WebElement dashboardSelectorContainer;
	
	@FindBy(id = "customerdropdown")
	WebElement customerdropdown;
	
	@FindBy(id = "button_createprincipalcustomer")
	WebElement buttoncreateprincipalcustomer;
	
	@FindBy(id = "name")
	WebElement customerName;
	
	@FindBy(id = "account|NoRelationship|Form|Mscrm.Form.account.Save")
	WebElement saveButton;
	
	@FindBy(id = "account|NoRelationship|Form|ewb.account.SaveAndComplete.Button")
	WebElement saveAndCompleteButton;
	
	@FindBy(id = "button_confirm")
	WebElement buttonconfirm;
	
	@FindBy(id = "button_removerelationship")
	WebElement buttonremoverelationship;
	
	@FindBy(xpath = "//*[@id=\"account|NoRelationship|Form|ewb.account.NewPrincipalCustomer.Button\"]")
	WebElement UpdatePrincipalCustomerButton;
	
	
	@FindBy(xpath = "//*[@id=\"gridBodyTable\"]//tr[1]/td[2]")
	WebElement FirstRecordUnderPCD;
	
	@FindBy(xpath = "/html/body")
	WebElement pageContent;
	
	@FindBy(xpath = "//*[@id=\"customerdropdown\"]/option[2]")
	WebElement FirstValueFromDropDown;
	
	@FindBy(id = "FormTitle")
	WebElement FormTitle;
	
	@FindBy(id = "account|NoRelationship|Form|ewb.account.AddRelationship.Button")
	WebElement AddRelationship;
	
	@FindBy(id = "account|NoRelationship|Form|ewb.account.RemoveRelationship.Button")
	WebElement RemoveRelationship;
	
	
	@FindBy(id = "txtSearch")
	WebElement txtSearch;
	
	@FindBy(id = "button_search")
	WebElement buttonsearch;
	
	@FindBy(id = "table_customers")
	WebElement tablecustomers;
	
	@FindBy(id = "a_relatedcustomers")
	WebElement relatedcustomers;
	
	@FindBy(id = "{3d8a8caa-79ab-e811-810c-005056886944}")
	WebElement PrincipalCustomerDashboard;
	
	@FindBy(id = "{0286644a-f6bb-e811-8112-005056886944}")
	WebElement CRTAdminDashboard;
	
	@FindBy(id = "ddlSearchBy")
	WebElement ddlSearchBy;
	
	@FindBy(xpath = "//*[@id=\"ddlSearchBy\"]/option[2]")
	WebElement selectCIS;
	
	@FindBy(id = "customercomments")
	WebElement customercomments;
	
	@FindBy(xpath = "//*[@id=\"Component7204d22_divDataArea\"]//tbody/tr[1]")
	WebElement RelationshipPendingForApprovalFirstRecord;
	
	@FindBy(id = "gridBodyTable_primaryField_{A7340DB2-0635-E911-810E-005056882DF7}_0")
	WebElement CIS;
	
	@FindBy(id = "ewb_customergrouprelationship|NoRelationship|Form|ewb.ewb_customergrouprelationship.ApproveRelationship.Button")
	WebElement ApproveRelationshipButton;
	
	@FindBy(id = "ewb_customergrouprelationship|NoRelationship|Form|ewb.ewb_customergrouprelationship.RejectRelationship.Button")
	WebElement RejectRelationshipButton;
	
	@FindBy(id = "table_relatedcustomers")
	WebElement tablerelatedcustomers;
	
	public void NavigatingToPrincipalCustomerDashBoard() throws InterruptedException {
		try {
			BrowserHelper.refresh(driver);
			BrowserHelper.sleep(10);
			BrowserHelper.clickOnElement(driver, clickOnhomeButtonImage);
			log.info("clicked on home Button Image :-" + clickOnhomeButtonImage.toString());
			BrowserHelper.sleep(2);
			BrowserHelper.clickOnElement(driver, clickOnNewCRTlink);
			BrowserHelper.sleep(2);
			log.info("clicked on  :-" + clickOnNewCRTlink.toString());
			BrowserHelper.clickOnElement(driver, navdashboards);
			BrowserHelper.sleep(2);
			log.info("clicked on:-" + navdashboards.toString());
			BrowserHelper.switchToDefaultContent(driver);
			log.info("Switching to Frame");
			BrowserHelper.switchToFrame_byName("contentIFrame0", driver);
			BrowserHelper.sleep(5);
			BrowserHelper.waitForElementLocated(driver, dashboardSelectorContainer);
			BrowserHelper.clickOnElement(driver, dashboardSelectorContainer);
			BrowserHelper.sleep(2);
			BrowserHelper.clickOnElement(driver, PrincipalCustomerDashboard);
			BrowserHelper.sleep(2);
			boolean crtPrincipalCustomerDashBoard = BrowserHelper.isTextPresent(driver, "Principal Customer Dashboard");

			if (crtPrincipalCustomerDashBoard == true) {
				log.info("Principal Customer Dashboard Displayed SuccessFully");
			}
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	
	public void SelectFirstRecordFromDashBoard() throws InterruptedException {
		try {
			BrowserHelper.switchToDefaultContent(driver);
			BrowserHelper.switchToFrame_byName("contentIFrame0", driver);
			BrowserHelper.switchToFrame_byName("dashboardFrame", driver);
			//BrowserHelper.clickOnElement(driver, FirstRecordUnderPCD);
			
			BrowserHelper.actionDoubleClick(driver, FirstRecordUnderPCD);
			log.info("clicked on First Record :-" + FirstRecordUnderPCD.toString());
			System.out.println("clicked on First Record :-" + FirstRecordUnderPCD.toString());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	
	public void UpdatePrincipalCustomerWithExistingUser() throws InterruptedException {
		try {
			BrowserHelper.switchToDefaultContent(driver);
			BrowserHelper.clickOnElement(driver, UpdatePrincipalCustomerButton);
			BrowserHelper.sleep(3);
			Reporter.log("Update Principal Customer Details page is displayed.");
			log.info("Update Principal Customer Details page is displayed.");
			Reporter.log("Update Principal Customer Details page is displayed.");
			BrowserHelper.switchToDefaultContent(driver);
			BrowserHelper.switchToFrame_byName("InlineDialog_Iframe", driver);
			BrowserHelper.waitForElementLocated(driver, customerdropdown);
			Reporter.log("Selecting existing Principal Customer from Dropdown.");
			log.info("Selecting existing Principal Customer from Dropdown");
			Reporter.log("Selecting existing Principal Customer from Dropdown");
			BrowserHelper.clickOnElement(driver, customerdropdown);
			BrowserHelper.clickOnElement(driver, FirstValueFromDropDown);
			String selectedValue = FirstValueFromDropDown.getText();
			System.out.println("Selected Value :-" + selectedValue);
			BrowserHelper.sleep(3);
			log.info("Clicking on Conform Button buttonconfirm");
			BrowserHelper.clickOnElement(driver, buttonconfirm);
			BrowserHelper.sleep(3);
			driver.switchTo().alert().accept();
			BrowserHelper.sleep(5);
			BrowserHelper.switchToDefaultContent(driver);
			BrowserHelper.switchToFrame_byName("contentIFrame0", driver);
			String DisplayedValueIntheForm = FormTitle.getText();
			System.out.println("Displayed Value :-" + DisplayedValueIntheForm);
			if(DisplayedValueIntheForm.equalsIgnoreCase(selectedValue)) {
				System.out.println("Principal customer has been updated successfully ");
			}
			else {
				System.out.println("Principal customer has been not updated as expected");
			}
			Assert.assertEquals(DisplayedValueIntheForm, selectedValue);
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	
	public void UpdatePrincipalCustomerWithNewUser() throws InterruptedException {
		try {
			BrowserHelper.switchToDefaultContent(driver);
			BrowserHelper.clickOnElement(driver, UpdatePrincipalCustomerButton);
			BrowserHelper.sleep(3);
			Reporter.log("Update Principal Customer Details page is displayed.");
			log.info("Update Principal Customer Details page is displayed.");
			Reporter.log("Update Principal Customer Details page is displayed.");
			BrowserHelper.switchToDefaultContent(driver);
			BrowserHelper.switchToFrame_byName("InlineDialog_Iframe", driver);
			BrowserHelper.waitForElementLocated(driver, customerdropdown);
			
			BrowserHelper.clickOnElement(driver, buttoncreateprincipalcustomer);
			BrowserHelper.sleep(3);
			String EnteredValueinCustomerName = RandomStringUtils.randomAlphanumeric(7);
			System.out.println("Entered Value in Principal Customer Name :-" + EnteredValueinCustomerName);
			BrowserHelper.switchToDefaultContent(driver);
			BrowserHelper.switchToFrame_byName("contentIFrame0", driver);
			customerName.click();
			BrowserHelper.sleep(2);
			//customerName.sendKeys(EnteredValueinCustomerName);
			BrowserHelper.actionEnterValue(driver, customerName, EnteredValueinCustomerName);
			BrowserHelper.sleep(3);
			BrowserHelper.switchToDefaultContent(driver);
			BrowserHelper.clickOnElement(driver, saveButton);
			BrowserHelper.sleep(3);
			BrowserHelper.clickOnElement(driver, saveAndCompleteButton);
			BrowserHelper.sleep(3);
			BrowserHelper.switchToDefaultContent(driver);
			BrowserHelper.switchToFrame_byName("contentIFrame0", driver);
			String DisplayedValueIntheForm = FormTitle.getText();
			System.out.println("Displayed Value :-" + DisplayedValueIntheForm);
			if(DisplayedValueIntheForm.equalsIgnoreCase(EnteredValueinCustomerName)) {
				System.out.println("Principal customer has been updated successfully with new customer");
			}
			else {
				System.out.println("Principal customer has been not updated as expected");
			}
			Assert.assertEquals(DisplayedValueIntheForm, EnteredValueinCustomerName);
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	
	
	public void AddRelationShip() throws InterruptedException {
		try {
			BrowserHelper.switchToDefaultContent(driver);
			BrowserHelper.clickOnElement(driver, AddRelationship);
			BrowserHelper.sleep(3);
			BrowserHelper.switchToDefaultContent(driver);
			BrowserHelper.switchToFrame_byName("InlineDialog_Iframe", driver);
			BrowserHelper.waitForElementLocated(driver, txtSearch);
			Reporter.log("Entering value in customer name search text box");
	   		log.info("Entering value in customer name search text box");
			txtSearch.sendKeys("MJ TESTING SOLUTIONS");
			BrowserHelper.sleep(2);
			BrowserHelper.clickOnElement(driver, buttonsearch);
			BrowserHelper.sleep(3);
			
			BrowserHelper.actionDoubleClick(driver, tablecustomers);
			BrowserHelper.sleep(2);
			BrowserHelper.clickOnElement(driver, buttonconfirm);
			BrowserHelper.sleep(2);
			
			BrowserHelper.switchToDefaultContent(driver);
			BrowserHelper.switchToFrame_byName("contentIFrame0", driver);
			BrowserHelper.switchToFrame_byName("WebResource_leftNavigationBar", driver);
			BrowserHelper.clickOnElement(driver, relatedcustomers);
	   		BrowserHelper.sleep(3);
	   		Reporter.log("Verifying the addedRelationship under customer details form");
	   		log.info("Verifying the addedRelationship under customer details form");
	   		
            String CustomerstableContent = tablerelatedcustomers.getText();
	   		
	   		boolean returnedBooleanValuse = StringUtils.contains(CustomerstableContent, "MJ TESTING SOLUTIONS");
	   		Assert.assertEquals(returnedBooleanValuse, true);
	   		
			//driver.getPageSource().contains("MJ TESTING SOLUTIONS");
			Reporter.log("Added Relationship is showing under customer details form");
	   		log.info("Added Relationship is showing under customer details form");

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	
	public void AddRelationShipWithDifferentTL() throws InterruptedException {
		try {
			BrowserHelper.switchToDefaultContent(driver);
			BrowserHelper.clickOnElement(driver, AddRelationship);
			BrowserHelper.sleep(3);
			BrowserHelper.switchToDefaultContent(driver);
			BrowserHelper.switchToFrame_byName("InlineDialog_Iframe", driver);
			
			BrowserHelper.clickOnElement(driver, ddlSearchBy);
			BrowserHelper.sleep(2);
			BrowserHelper.clickOnElement(driver, selectCIS);
			BrowserHelper.sleep(2);
			BrowserHelper.waitForElementLocated(driver, txtSearch);
			Reporter.log("Entering value in customer name search text box");
	   		log.info("Entering value in customer name search text box");
			txtSearch.sendKeys("682430");
			BrowserHelper.sleep(2);
			BrowserHelper.clickOnElement(driver, buttonsearch);
			BrowserHelper.sleep(5);
			
			BrowserHelper.actionDoubleClick(driver, tablecustomers);
			BrowserHelper.sleep(2);
			BrowserHelper.clickOnElement(driver, buttonconfirm);
			
			BrowserHelper.sleep(3);
			driver.switchTo().alert().accept();
			
			customercomments.sendKeys("Test Comment");
			BrowserHelper.sleep(2);
			BrowserHelper.clickOnElement(driver, buttonconfirm);
			
			BrowserHelper.clickOnElement(driver, clickOnhomeButtonImage);
			log.info("clicked on home Button Image :-" + clickOnhomeButtonImage.toString());
			BrowserHelper.sleep(2);
			BrowserHelper.clickOnElement(driver, clickOnNewCRTlink);
			BrowserHelper.sleep(2);
			log.info("clicked on  :-" + clickOnNewCRTlink.toString());
			BrowserHelper.clickOnElement(driver, navdashboards);
			BrowserHelper.sleep(2);
			log.info("clicked on:-" + navdashboards.toString());
			BrowserHelper.switchToDefaultContent(driver);
			BrowserHelper.switchToFrame_byName("contentIFrame1", driver);
			
			BrowserHelper.sleep(5);
			BrowserHelper.waitForElementLocated(driver, dashboardSelectorContainer);
			BrowserHelper.clickOnElement(driver, dashboardSelectorContainer);
			BrowserHelper.sleep(2);
			BrowserHelper.clickOnElement(driver, CRTAdminDashboard);
			BrowserHelper.sleep(2);
			boolean crtAdminDashboard = BrowserHelper.isTextPresent(driver, "CRT Admin Dashboard");

			if (crtAdminDashboard == true) {
				log.info("CRT Admin Dashboard Displayed SuccessFully");
			}
			Robot robot = new Robot();
			robot.keyPress(KeyEvent.VK_PAGE_DOWN);
			robot.keyRelease(KeyEvent.VK_PAGE_DOWN);
			BrowserHelper.switchToFrame_byName("dashboardFrame", driver);
			BrowserHelper.actionDoubleClick(driver, RelationshipPendingForApprovalFirstRecord);
			log.info("clicked on Relationship Pending For Approval First Record");
			System.out.println("clicked on Relationship Pending For Approval First Record");
			
			
			BrowserHelper.sleep(3);
			BrowserHelper.waitForElementLocated(driver, ApproveRelationshipButton);
			String ApproveRelationshipButtontext = ApproveRelationshipButton.getText();
			if(ApproveRelationshipButtontext.equalsIgnoreCase("APPROVE RELATIONSHIP")) {
				System.out.println("Approve Relationship Button is displayed as expected");
			}
			else {
				System.out.println("Approve Relationship Button is not displayed as expected");
			}
			Assert.assertEquals(ApproveRelationshipButtontext, "APPROVE RELATIONSHIP");
			
			BrowserHelper.waitForElementLocated(driver, RejectRelationshipButton);
			String RejectRelationshipButtontext = RejectRelationshipButton.getText();
			if(RejectRelationshipButtontext.equalsIgnoreCase("REJECT RELATIONSHIP")) {
				System.out.println("Reject Relationship Button is displayed as expected");
			}
			else {
				System.out.println("Reject Relationship Button is not displayed as expected");
			}
			Assert.assertEquals(RejectRelationshipButtontext, "REJECT RELATIONSHIP");
			
			Reporter.log("Approve Relationship and Reject Relationship Buttons are displayed as expected");
	   		log.info("Approve Relationship and Reject Relationship Buttons are displayed as expected");

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	
	public void RemoveRelationShip() throws InterruptedException {
		try {
			BrowserHelper.switchToDefaultContent(driver);
			BrowserHelper.clickOnElement(driver, RemoveRelationship);
			BrowserHelper.sleep(3);
			Reporter.log("Remove Relationship page is displayed.");
			log.info("Remove Relationship page is displayed.");
			BrowserHelper.switchToDefaultContent(driver);
			BrowserHelper.switchToFrame_byName("InlineDialog_Iframe", driver);
			BrowserHelper.waitForElementLocated(driver, customerdropdown);
			Reporter.log("Selecting existing  Customer from Dropdown.");
			log.info("Selecting existing  Customer from Dropdown");
			BrowserHelper.clickOnElement(driver, customerdropdown);
			BrowserHelper.clickOnElement(driver, FirstValueFromDropDown);
			String selectedCustomerValue = FirstValueFromDropDown.getText();
			System.out.println("Selected Value :-" + selectedCustomerValue);
			BrowserHelper.sleep(3);
			
			BrowserHelper.actionDoubleClick(driver, tablecustomers);
			BrowserHelper.sleep(5);
				
			BrowserHelper.clickOnElement(driver, buttonremoverelationship);
			BrowserHelper.sleep(5);
			
//			BrowserHelper.switchToDefaultContent(driver);
//			BrowserHelper.switchToFrame_byName("contentIFrame0", driver);
//			String DisplayedValueInthePrincipalForm = FormTitle.getText();
//			System.out.println("Displayed Value :-" + DisplayedValueInthePrincipalForm);
//			if(DisplayedValueInthePrincipalForm.equalsIgnoreCase(selectedCustomerValue)) {
//				System.out.println("Principal customer has been updated successfully ");
//			}
//			else {
//				System.out.println("Principal customer has been not updated as expected");
//			}
//			Assert.assertEquals(DisplayedValueInthePrincipalForm, selectedCustomerValue);
			
			BrowserHelper.switchToDefaultContent(driver);
			BrowserHelper.switchToFrame_byName("contentIFrame0", driver);
			BrowserHelper.switchToFrame_byName("WebResource_leftNavigationBar", driver);
			BrowserHelper.clickOnElement(driver, relatedcustomers);
	   		BrowserHelper.sleep(3);
	   		Reporter.log("Verifying the Removed Relationship under customer details form");
	   		log.info("Verifying the Removed Relationship under customer details form");
	   		
	   		BrowserHelper.switchToDefaultContent(driver);
			BrowserHelper.switchToFrame_byName("contentIFrame0", driver);
			BrowserHelper.switchToFrame_byName("WebResource_PCRRelatedCustomers", driver);
	   		
	   		String tableContent = tablerelatedcustomers.getText();
	   		
	   		boolean returnedBoolean = StringUtils.contains(tableContent, selectedCustomerValue);
	   		Assert.assertEquals(returnedBoolean, false);
			Reporter.log("Removed Relationship is not showing under customer details form");
	   		log.info("Removed Relationship is not showing under customer details form");
			
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	
	
	public void RejectRelationShip() throws InterruptedException {
		try {
			BrowserHelper.switchToDefaultContent(driver);
			BrowserHelper.clickOnElement(driver, AddRelationship);
			BrowserHelper.sleep(3);
			BrowserHelper.switchToDefaultContent(driver);
			BrowserHelper.switchToFrame_byName("InlineDialog_Iframe", driver);
			
			BrowserHelper.clickOnElement(driver, ddlSearchBy);
			BrowserHelper.sleep(2);
			BrowserHelper.clickOnElement(driver, selectCIS);
			BrowserHelper.sleep(2);
			BrowserHelper.waitForElementLocated(driver, txtSearch);
			Reporter.log("Entering value in customer name search text box");
	   		log.info("Entering value in customer name search text box");
			txtSearch.sendKeys("682430");
			BrowserHelper.sleep(2);
			BrowserHelper.clickOnElement(driver, buttonsearch);
			BrowserHelper.sleep(5);
			
			BrowserHelper.actionDoubleClick(driver, tablecustomers);
			BrowserHelper.sleep(2);
			BrowserHelper.clickOnElement(driver, buttonconfirm);
			
			BrowserHelper.sleep(3);
			driver.switchTo().alert().accept();
			
			customercomments.sendKeys("Test Comment");
			BrowserHelper.sleep(2);
			BrowserHelper.clickOnElement(driver, buttonconfirm);
			
			BrowserHelper.clickOnElement(driver, clickOnhomeButtonImage);
			log.info("clicked on home Button Image :-" + clickOnhomeButtonImage.toString());
			BrowserHelper.sleep(2);
			BrowserHelper.clickOnElement(driver, clickOnNewCRTlink);
			BrowserHelper.sleep(2);
			log.info("clicked on  :-" + clickOnNewCRTlink.toString());
			BrowserHelper.clickOnElement(driver, navdashboards);
			BrowserHelper.sleep(2);
			log.info("clicked on:-" + navdashboards.toString());
			BrowserHelper.switchToDefaultContent(driver);
			BrowserHelper.switchToFrame_byName("contentIFrame1", driver);
			
			BrowserHelper.sleep(5);
			BrowserHelper.waitForElementLocated(driver, dashboardSelectorContainer);
			BrowserHelper.clickOnElement(driver, dashboardSelectorContainer);
			BrowserHelper.sleep(2);
			BrowserHelper.clickOnElement(driver, CRTAdminDashboard);
			BrowserHelper.sleep(2);
			boolean crtAdminDashboard = BrowserHelper.isTextPresent(driver, "CRT Admin Dashboard");

			if (crtAdminDashboard == true) {
				log.info("CRT Admin Dashboard Displayed SuccessFully");
			}
			Robot robot = new Robot();
			robot.keyPress(KeyEvent.VK_PAGE_DOWN);
			robot.keyRelease(KeyEvent.VK_PAGE_DOWN);
			BrowserHelper.switchToFrame_byName("dashboardFrame", driver);
			//String CIS = RelationshipPendingForApprovalFirstRecord.getText();
			//String CIS = RelationshipPendingForApprovalFirstRecord.getText();
			BrowserHelper.actionDoubleClick(driver, RelationshipPendingForApprovalFirstRecord);
			log.info("clicked on Relationship Pending For Approval First Record");
			System.out.println("clicked on Relationship Pending For Approval First Record");
			
			
//			BrowserHelper.sleep(3);
//			BrowserHelper.waitForElementLocated(driver, ApproveRelationshipButton);
//			String ApproveRelationshipButtontext = ApproveRelationshipButton.getText();
//			if(ApproveRelationshipButtontext.equalsIgnoreCase("APPROVE RELATIONSHIP")) {
//				System.out.println("Approve Relationship Button is displayed as expected");
//			}
//			else {
//				System.out.println("Approve Relationship Button is not displayed as expected");
//			}
//			Assert.assertEquals(ApproveRelationshipButtontext, "APPROVE RELATIONSHIP");
			
			BrowserHelper.waitForElementLocated(driver, RejectRelationshipButton);
			String RejectRelationshipButtontext = RejectRelationshipButton.getText();
			if(RejectRelationshipButtontext.equalsIgnoreCase("REJECT RELATIONSHIP")) {
				System.out.println("Reject Relationship Button is displayed as expected");
			}
			else {
				System.out.println("Reject Relationship Button is not displayed as expected");
			}
			Assert.assertEquals(RejectRelationshipButtontext, "REJECT RELATIONSHIP");
			
			Reporter.log("Approve Relationship and Reject Relationship Buttons are displayed as expected");
	   		log.info("Approve Relationship and Reject Relationship Buttons are displayed as expected");
	   		
	   		BrowserHelper.clickOnElement(driver, RejectRelationshipButton);
	   		BrowserHelper.sleep(10);
	   		Reporter.log("Reject Relationship Button clicked successfully");
	   		log.info("Reject Relationship Button clicked successfully");
	   		
	   		BrowserHelper.switchToDefaultContent(driver);
			BrowserHelper.switchToFrame_byName("contentIFrame0", driver);
	   		String CIS = pageContent.getText();
	   		System.out.println(CIS);
	   		boolean returnedBooleanValue = StringUtils.contains(CIS, "682430");
	   		System.out.println(returnedBooleanValue);
	   		Assert.assertEquals(returnedBooleanValue, false);
			Reporter.log("Rejected relationship successfully");
	   		log.info("Rejected relationship successfully");

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	
	public void ApproveRelationShip() throws InterruptedException {
		try {
			BrowserHelper.switchToDefaultContent(driver);
			BrowserHelper.clickOnElement(driver, AddRelationship);
			BrowserHelper.sleep(3);
			BrowserHelper.switchToDefaultContent(driver);
			BrowserHelper.switchToFrame_byName("InlineDialog_Iframe", driver);
			
			BrowserHelper.clickOnElement(driver, ddlSearchBy);
			BrowserHelper.sleep(2);
			BrowserHelper.clickOnElement(driver, selectCIS);
			BrowserHelper.sleep(2);
			BrowserHelper.waitForElementLocated(driver, txtSearch);
			Reporter.log("Entering value in customer name search text box");
	   		log.info("Entering value in customer name search text box");
			txtSearch.sendKeys("682430");
			BrowserHelper.sleep(2);
			BrowserHelper.clickOnElement(driver, buttonsearch);
			BrowserHelper.sleep(5);
			
			BrowserHelper.actionDoubleClick(driver, tablecustomers);
			BrowserHelper.sleep(2);
			BrowserHelper.clickOnElement(driver, buttonconfirm);
			
			BrowserHelper.sleep(3);
			driver.switchTo().alert().accept();
			
			customercomments.sendKeys("Test Comment");
			BrowserHelper.sleep(2);
			BrowserHelper.clickOnElement(driver, buttonconfirm);
			
			BrowserHelper.clickOnElement(driver, clickOnhomeButtonImage);
			log.info("clicked on home Button Image :-" + clickOnhomeButtonImage.toString());
			BrowserHelper.sleep(2);
			BrowserHelper.clickOnElement(driver, clickOnNewCRTlink);
			BrowserHelper.sleep(2);
			log.info("clicked on  :-" + clickOnNewCRTlink.toString());
			BrowserHelper.clickOnElement(driver, navdashboards);
			BrowserHelper.sleep(2);
			log.info("clicked on:-" + navdashboards.toString());
			BrowserHelper.switchToDefaultContent(driver);
			BrowserHelper.switchToFrame_byName("contentIFrame1", driver);
			
			BrowserHelper.sleep(5);
			BrowserHelper.waitForElementLocated(driver, dashboardSelectorContainer);
			BrowserHelper.clickOnElement(driver, dashboardSelectorContainer);
			BrowserHelper.sleep(2);
			BrowserHelper.clickOnElement(driver, CRTAdminDashboard);
			BrowserHelper.sleep(2);
			boolean crtAdminDashboard = BrowserHelper.isTextPresent(driver, "CRT Admin Dashboard");

			if (crtAdminDashboard == true) {
				log.info("CRT Admin Dashboard Displayed SuccessFully");
			}
			Robot robot = new Robot();
			robot.keyPress(KeyEvent.VK_PAGE_DOWN);
			robot.keyRelease(KeyEvent.VK_PAGE_DOWN);
			BrowserHelper.switchToFrame_byName("dashboardFrame", driver);
			BrowserHelper.actionDoubleClick(driver, RelationshipPendingForApprovalFirstRecord);
			log.info("clicked on Relationship Pending For Approval First Record");
			System.out.println("clicked on Relationship Pending For Approval First Record");
			
			
			BrowserHelper.sleep(3);
			BrowserHelper.waitForElementLocated(driver, ApproveRelationshipButton);
			String ApproveRelationshipButtontext = ApproveRelationshipButton.getText();
			if(ApproveRelationshipButtontext.equalsIgnoreCase("APPROVE RELATIONSHIP")) {
				System.out.println("Approve Relationship Button is displayed as expected");
			}
			else {
				System.out.println("Approve Relationship Button is not displayed as expected");
			}
			Assert.assertEquals(ApproveRelationshipButtontext, "APPROVE RELATIONSHIP");
			
			Reporter.log("Approve Relationship and Reject Relationship Buttons are displayed as expected");
	   		log.info("Approve Relationship and Reject Relationship Buttons are displayed as expected");
	   		
	   		BrowserHelper.clickOnElement(driver, ApproveRelationshipButton);
	   		BrowserHelper.sleep(10);
	   		Reporter.log("Approve Relationship Button clicked successfully");
	   		log.info("Approve Relationship Button clicked successfully");
	   		
	   		BrowserHelper.switchToDefaultContent(driver);
			BrowserHelper.switchToFrame_byName("contentIFrame0", driver);
			BrowserHelper.switchToFrame_byName("WebResource_leftNavigationBar", driver);
			BrowserHelper.clickOnElement(driver, relatedcustomers);
	   		BrowserHelper.sleep(3);
	   		Reporter.log("Verifying the addedRelationship under customer details form");
	   		log.info("Verifying the addedRelationship under customer details form");
	   		
            String CustomerstableContent = tablerelatedcustomers.getText();
	   		
	   		boolean returnedBooleanValuse = StringUtils.contains(CustomerstableContent, "682430");
	   		Assert.assertEquals(returnedBooleanValuse, true);
	   		Reporter.log("Approved Relationship is displayed under  customer details form successfully");
	   		log.info("Approved Relationship is displayed under  customer details form successfully");

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	
	
	
	public void clickOnLinkText(String linktext) {
		BrowserHelper.switchToDefaultContent(driver);
		BrowserHelper.switchToFrame_byName("contentIFrame0", driver);
		BrowserHelper.switchToFrame_byName("WebResource_LoanRequestMenu", driver);
		
		driver.findElement(By.linkText(linktext)).click();
		
		BrowserHelper.switchToDefaultContent(driver);
		BrowserHelper.switchToFrame_byName("contentIFrame0", driver);
		
		
	}
	
}
