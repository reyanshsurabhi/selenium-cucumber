package com.ewbc.qa.web.SmokeSuite;

import com.ewbc.qa.web.framework.base.BaseException;
import com.ewbc.qa.web.framework.base.BaseTest;
import com.ewbc.qa.web.framework.base.BrowserHelper;
import com.ewbc.qa.web.framework.base.config.ConfigInput;
import com.ewbc.qa.web.framework.core.DriverManager;
import com.ewbc.qa.web.framework.utility.TestListener;
import com.ewbc.qa.web.pages.BBPremierLoginPage;
import com.ewbc.qa.web.pages.CRTDasboard;
import org.apache.log4j.Logger;
import org.junit.Assert;
import org.testng.Reporter;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import java.io.IOException;

@Listeners({TestListener.class})
public class SampleBVTTest extends BaseTest {
    public final static Logger log = Logger.getLogger(SampleBVTTest.class);
    static CRTDasboard CRTDashboardpage;
    static BBPremierLoginPage bbpremierLoginPage;

    @BeforeMethod
    public void setup() throws IOException, BaseException {
        CRTDashboardpage = new CRTDasboard(DriverManager.getDriver());
        bbpremierLoginPage = new BBPremierLoginPage(DriverManager.getDriver());
    }

    @Test
    public void SampleTest() throws Exception {
        extentTest = extent.startTest("Sample Test");
        log.info("Navigating to Home page");
        Reporter.log("Navigating to Home page");
//        DriverManager.getDriver().get(ConfigInput.url);
        BrowserHelper.sleep(5);
        bbpremierLoginPage.bbpLogin("comp1", "usid123" , "psswd123");
    }

    @Test
    public void SampleTestDefaultBrowser() throws Exception {
//    extentTest = extent.startTest("Sample Test - Chrome");
        log.info("Navigating to Home page");
        Reporter.log("Navigating to Home page");
        DriverManager.getDriver().get(ConfigInput.url);
        BrowserHelper.sleep(5);
        bbpremierLoginPage.bbpLogin("comp1", "usid123" , "psswd123");
    }

    @Parameters("browserName")
    @Test
    public void SampleTestIE(String browserName) throws Exception {
        System.out.println("SampleTestIE(String browserName)" + browserName);
//        extentTest = extent.startTest("Sample Test");
//        log.info("Navigating to Home page");
//        Reporter.log("Navigating to Home page");
        DriverManager.getDriver().get(ConfigInput.url);
//        BrowserHelper.sleep(5);
//        bbpremierLoginPage.bbpLogin("comp1", "usid123" , "psswd123");
    }

}
