package com.ewbc.qa.web.pages;

import com.ewbc.qa.web.framework.base.BaseException;
import com.ewbc.qa.web.framework.base.BasePage;
import com.ewbc.qa.web.framework.base.BrowserHelper;
import com.ewbc.qa.web.framework.base.config.ConfigInput;
import com.ewbc.qa.web.framework.core.DriverManager;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.testng.Reporter;

import java.io.IOException;

public class BBPremierLoginPage extends BasePage {
	public final static Logger log = Logger.getLogger(BBPremierLoginPage.class.getName());
	WebDriver driver;
	private static WebElement element = null;

	public BBPremierLoginPage(WebDriver driver) throws IOException, BaseException {
		super(driver);
		this.driver = driver;
	}

	@FindBy(id = "splash-7717216-close-button")
	WebElement splashclosebutton;

	@FindBy(id = "model_organizationId")
	WebElement companyId;

	@FindBy(id = "model_userId")
	WebElement userId;

	@FindBy(id = "model_password")
	WebElement password;

	@FindBy(id = "btnLogin")
	WebElement btnLogin;

	@FindBy(id = "bank-logo")
	WebElement banklogo;

	@FindBy(id = "Stale_Balance_Warning")
	WebElement StaleBalanceWarning;

	@FindBy(id = "btnSubmit")
	WebElement StaleBalanceButton;

	public void clickOnSplashCloseButton() throws Exception {
		BrowserHelper.sleep(2);
		if (BrowserHelper.isElementPresent(driver, splashclosebutton) == true) {
			Reporter.log("Splash window displayed and Clicking on Close Button");
			BrowserHelper.clickOnElement(driver, splashclosebutton);
			BrowserHelper.sleep(1);
		}
	}

	public void bbpLogin(String cid, String uid, String psw) throws Exception {
		log.info("Navigating to BB Premier Login page");
		Reporter.log("Navigating to BB Premier Login page");
		Reporter.log("Entering the URL and Navigating to BB Premier Login page");
		DriverManager.getDriver().get(ConfigInput.url);
		BrowserHelper.sleep(4);
		// Assert.assertTrue(false);
		log.info("Clicking on SplashScreen if it exist");
		Reporter.log("Clicking on SplashScreen if it exist");
		clickOnSplashCloseButton();
        Reporter.log("User Details: " + cid + ", " + uid + ", " + psw);
		Reporter.log("Clicking on the CompanyId edit box and entering the value");
		BrowserHelper.actionEnterValue(driver, companyId, cid);
		Reporter.log("Clicking on the UserID edit box and entering the value");
		BrowserHelper.actionEnterValue(driver, userId, uid);
		Reporter.log("Clicking on the Password edit box and entering the value");
		BrowserHelper.actionEnterValue(driver, password, psw);
		Reporter.log("Clicking on the Login button and verifying the EastWest Bank home page logo");
		BrowserHelper.clickOnElement(driver, btnLogin);
		BrowserHelper.sleep(1);
		clickOnStaleBalanceWarningOkButton();
		//BrowserHelper.waitForElementVisible(driver, banklogo);
	}

	public void clickOnStaleBalanceWarningOkButton() throws Exception {
		if (BrowserHelper.isElementPresent(driver, StaleBalanceWarning)) {
			Reporter.log("Stale Balance Warning displayed and Clicking on OK Button");
			BrowserHelper.clickOnElement(driver, StaleBalanceButton);
		}
	}

}
