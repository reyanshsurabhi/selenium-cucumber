package info.seleniumcucumber.methods;

public class JavascriptHandlingMethods extends SelectElementByType implements BaseTest {
//	protected WebDriver getDriver() = DriverUtil.getDefaultDriver();

    /**
     * Method to handle alert
     *
     * @param decision : String : Accept or dismiss alert
     */
    public void handleAlert(String decision) {

        if (decision.equals("accept"))
            getDriver().switchTo().alert().accept();
        else
            getDriver().switchTo().alert().dismiss();
    }
}
