package info.seleniumcucumber.methods;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class ObjectRep implements BaseTest {
    static String currentPath = System.getProperty("user.dir");
    static String ORfile = currentPath + "/src/test/resources/OR/object_repository.properties";
    static Properties obj = new Properties();


    public ObjectRep() {
        FileInputStream objfile = null;

        try {
            objfile = new FileInputStream(ORfile);
            obj.load(objfile);

        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } finally {
            try {
                if (objfile != null) {
                    objfile.close();
                }
            } catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }

        }

    }

    public String getAccessType(String ObjectName) {

        return obj.getProperty(ObjectName).split(":")[0];

    }


    public String getAccessValue(String ObjectName) {

        return obj.getProperty(ObjectName).split(":")[1];

    }

}
