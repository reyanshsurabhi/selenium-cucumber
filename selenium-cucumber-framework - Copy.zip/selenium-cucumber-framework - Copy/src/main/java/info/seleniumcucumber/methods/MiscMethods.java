package info.seleniumcucumber.methods;

import env.DriverUtil;
import org.openqa.selenium.JavascriptExecutor;

import java.io.FileInputStream;
import java.util.*;

public class MiscMethods implements BaseTest {

    static String currentPath = System.getProperty("user.dir");
    static String configFile = currentPath + "/src/test/resources/config/runconfig.properties";
    static Properties configProp = new Properties();

    public boolean valid_locator_type(String type) {
        return Arrays.asList("id", "class", "css", "name", "xpath", "linkText", "partialLinkText", "tagName").contains(type);
    }

    /**
     * Method to verify locator type
     *
     * @param type : String : Locator type (id, name, class, xpath, css)
     */
    public void validateLocator(String type) throws Exception {
        if (!valid_locator_type(type))
            throw new Exception("Invalid locator type - " + type);
    }

    // method to validate dropdown selector
    public boolean valid_option_by(String option_by) {
        return Arrays.asList("text", "value", "index").contains(option_by);
    }

    /**
     * Method to verify dropdown selector (text, value or index)
     *
     * @param optionBy : String : Locator type (text, value, index)
     */
    public void validateOptionBy(String optionBy) throws Exception {
        if (!valid_option_by(optionBy))
            throw new Exception("Invalid option by - " + optionBy);
    }

    /**
     * Method to verify dropdown selector (text, value or index)
     *
     * @param optionBy : String : Locator type (text, value, index)
     */
    public void Cancel_Print() throws Exception {
        if (getConfig("browser").toLowerCase().equals("chrome")) {
            Thread.sleep(10);
            String mainwindow = DriverUtil.getDefaultDriver("").getWindowHandle();
            Set<String> allWindowHandles = DriverUtil.getDefaultDriver("").getWindowHandles();
            List<String> aList = new ArrayList<String>(allWindowHandles);

            DriverUtil.getDefaultDriver("").switchTo().window(aList.get(1));
            navigationObj.switchToDefaultContent();

            System.out.println("Cancelling print.");

            JavascriptExecutor executor = (JavascriptExecutor) DriverUtil.getDefaultDriver("");
            executor.executeScript("document.querySelector(\"print-preview-app\").shadowRoot.querySelector(\"print-preview-sidebar\").shadowRoot.querySelector(\"print-preview-button-strip\").shadowRoot.querySelector(\"cr-button.cancel-button\").click()");
            DriverUtil.getDefaultDriver("").switchTo().window(mainwindow);
            System.out.println("Cancelled print.");
        } else {
            Runtime.getRuntime().exec(currentPath + "/src/test/resources/other/Cancel_Print.exe");

        }

    }

    public static String getConfig(String ConfigName) {

        FileInputStream configStream;
        String configValue = "";
        try {
            configStream = new FileInputStream(configFile);
            configProp.load(configStream);
            configValue = configProp.getProperty(ConfigName);
            configProp.clear();
            configStream.close();

        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        return configValue;

    }

}
