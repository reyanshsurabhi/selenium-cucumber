package info.seleniumcucumber.methods;

import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;

import env.DriverUtil;


public class NavigateMethods extends SelectElementByType implements BaseTest
{
	//SelectElementByType eleType= new SelectElementByType();
	private WebElement element=null;
	private String old_win = null;
	private String lastWinHandle;
	//protected WebDriver getDriver() = DriverUtil.getDefaultDriver();
	//WebDriver getDriver();
	/** Method to open link
	 * @param url : String : URL for navigation
	 */
	public void navigateTo(String url) 
	{
		getDriver().get(url);
	}
	
	public void navigateTo(String url,String user) 
	{
		getDriver(user).get(url);
	}
	
	/** Method to Refresh page
	 * @param url : String : URL for navigation
	 */
	public void refresh() 
	{	
		//getDriver()=DriverUtil.getDefaultDriver();
		getDriver().navigate().refresh();
	}
	
	/** Method to navigate back & forward
	 * @param direction : String : Navigate to forward or backward
	 */
	public void navigate(String direction)
	{
		//getDriver()=DriverUtil.getDefaultDriver();
		if (direction.equals("back"))
			getDriver().navigate().back();
		else
			getDriver().navigate().forward();
	}
	
	/** Method to quite webdriver instance */
	public void closeDriver()
	{
		//getDriver().close();
		DriverUtil.closeDriver();
		
		
	}
	
	/** Method to quit webdriver instance */
	public void quitDriver()
	{
		//getDriver()=DriverUtil.getDefaultDriver();
		getDriver().quit();
		
	}
	
	/** Method to return key by OS wise
	 * @return Keys : Return control or command key as per OS
	 */
	public Keys getKey()
	{
		String os = System.getProperty("os.name").toLowerCase();
		if(os.contains("win"))
			return Keys.CONTROL;
		else if (os.contains("nux") || os.contains("nix"))
			return Keys.CONTROL;
		else if (os.contains("mac"))
			return Keys.COMMAND;
		else
			return null;
	}
	
	/** Method to zoom in/out page
	 * @param inOut : String : Zoom in or out
	 */
	public void zoomInOut(String inOut)
	{
		//getDriver()=DriverUtil.getDefaultDriver();
		WebElement Sel= getDriver().findElement(getelementbytype("tagName","html"));
		if(inOut.equals("ADD"))
			Sel.sendKeys(Keys.chord(getKey(), Keys.ADD));
		else if(inOut.equals("SUBTRACT"))
			Sel.sendKeys(Keys.chord(getKey(), Keys.SUBTRACT));
		else if(inOut.equals("reset"))
			Sel.sendKeys(Keys.chord(getKey(), Keys.NUMPAD0));
	}
	
	/** Method to zoom in/out web page until web element displays
	 * @param accessType : String : Locator type (id, name, class, xpath, css)
	 * @param inOut : String : Zoom in or out
	 * @param accessName : String : Locator value
	 */
	public void zoomInOutTillElementDisplay(String accessType,String inOut,String accessName)
	{
		//getDriver()=DriverUtil.getDefaultDriver();
		Actions action = new Actions(getDriver());
		element = getWait().until(ExpectedConditions.presenceOfElementLocated(getelementbytype(accessType, accessName)));
		while(true)
		{
			if (element.isDisplayed())
				break;
			else
				action.keyDown(getKey()).sendKeys(inOut).keyUp(getKey()).perform();
		}
	}
	
	/** Method to resize browser
	 * @param width : int : Width for browser resize
	 * @param height : int : Height for browser resize
	 */
	public void resizeBrowser(int width, int height)
	{
		//getDriver()=DriverUtil.getDefaultDriver();
		getDriver().manage().window().setSize(new Dimension(width,height));
	}
	
	/** Method to maximize browser	 */
	public void maximizeBrowser()
	{
		//getDriver()=DriverUtil.getDefaultDriver();
		getDriver().manage().window().maximize();
	}
	
	/** Method to hover on element
	 * @param accessType : String : Locator type (id, name, class, xpath, css)
	 * @param accessName : String : Locator value
	 */
	public void hoverOverElement(String accessType, String accessName)
	{
		//getDriver()=DriverUtil.getDefaultDriver();
		Actions action = new Actions(getDriver());
		element = getWait().until(ExpectedConditions.presenceOfElementLocated(getelementbytype(accessType, accessName)));
		action.moveToElement(element).perform();
	}
	
	/** Method to scroll page to particular element
	 * @param accessType : String : Locator type (id, name, class, xpath, css)
	 * @param accessName : String : Locator value
	 */
	public void scrollToElement(String accessType, String accessName)
	{
		//getDriver()=DriverUtil.getDefaultDriver();
		element = getWait().until(ExpectedConditions.presenceOfElementLocated(getelementbytype(accessType, accessName)));
		JavascriptExecutor executor = (JavascriptExecutor)getDriver();
		executor.executeScript("arguments[0].scrollIntoView();", element);
	}
	
	/** Method to scroll page to top or end
	 * @param to : String : Scroll page to Top or End
	 * @throws Exception
	 */
	public void scrollPage(String to) throws Exception
	{
		//getDriver()=DriverUtil.getDefaultDriver();
		JavascriptExecutor executor = (JavascriptExecutor)getDriver();
		if (to.equals("end"))
			executor.executeScript("window.scrollTo(0,Math.max(document.documentElement.scrollHeight,document.body.scrollHeight,document.documentElement.clientHeight));");
		else if (to.equals("top"))
            executor.executeScript("window.scrollTo(Math.max(document.documentElement.scrollHeight,document.body.scrollHeight,document.documentElement.clientHeight),0);");
		else
			throw new Exception("Exception : Invalid Direction (only scroll \"top\" or \"end\")");
	}
	
	/** Method to scroll page to particular element
	 * @param accessType : String : Locator type (id, name, class, xpath, css)
	 * @param accessName : String : Locator value
	 */
	public void moveToElement(String accessType, String accessName)
	{
		//getDriver()=DriverUtil.getDefaultDriver();
		element = getWait().until(ExpectedConditions.presenceOfElementLocated(getelementbytype(accessType, accessName)));
		Actions actions = new Actions(getDriver());
		actions.moveToElement(element);
		actions.perform();
	}
	
	/**Method to switch to new window */
    public void switchToNewWindow()
    {
    	//getDriver()=DriverUtil.getDefaultDriver();
    	old_win = getDriver().getWindowHandle();
    	System.out.println("No of Windows "+getDriver().getWindowHandles().size());
    	for(String winHandle : getDriver().getWindowHandles()) 
    		 	lastWinHandle = winHandle;
    	    	getDriver().switchTo().window(lastWinHandle);
    }
    
    /** Method to switch to old window */
    public void switchToOldWindow()
    {
    	//getDriver()=DriverUtil.getDefaultDriver();
    	getDriver().switchTo().window(old_win);
    }
    
    /** Method to switch to window by title
     * @param windowTitle : String : Name of window title to switch
     * @throws Exception */
    public void switchToWindowByTitle(String windowTitle) throws Exception
    {
    	//getDriver()=DriverUtil.getDefaultDriver();
    	//System.out.println("++"+windowTitle+"++");
    	old_win = getDriver().getWindowHandle();
    	boolean winFound = false;
    	for(String winHandle : getDriver().getWindowHandles())
    	{
    		String str = getDriver().switchTo().window(winHandle).getTitle();
    		//System.out.println("**"+str+"**");
    		if (str.equals(windowTitle))
    		{
    			winFound = true;
    			break;
    		}
    	}
    	if (!winFound)
    		throw new Exception("Window having title "+windowTitle+" not found");
    }

    /**Method to close new window*/
    public void closeNewWindow()
    {
    	//getDriver()=DriverUtil.getDefaultDriver();
    	getDriver().close();
    }
    
    /** Method to switch frame using web element frame
     * @param accessType : String : Locator type (index, id, name, class, xpath, css)
	 * @param accessName : String : Locator value
     * */
    public void switchFrame(String accessType, String accessName)
    {
    	//getDriver()=DriverUtil.getDefaultDriver();
    	if(accessType.equalsIgnoreCase("index"))
    		getDriver().switchTo().frame(accessName);
    	else
    	{
    		element = getWait().until(ExpectedConditions.presenceOfElementLocated(getelementbytype(accessType, accessName)));
    		getDriver().switchTo().frame(element);
    	}
    }
    
    /** method to switch to default content*/
    public void switchToDefaultContent()
    {
    	//getDriver()=DriverUtil.getDefaultDriver();
    	getDriver().switchTo().defaultContent();
    }
}
