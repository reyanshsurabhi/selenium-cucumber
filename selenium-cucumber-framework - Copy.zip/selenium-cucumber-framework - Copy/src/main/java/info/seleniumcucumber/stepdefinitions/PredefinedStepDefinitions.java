package info.seleniumcucumber.stepdefinitions;

import java.io.IOException;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriverException;

import io.cucumber.java.Scenario;
import io.cucumber.java.After;
import io.cucumber.java.AfterStep;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import env.DriverUtil;
import info.seleniumcucumber.methods.BaseTest;
import info.seleniumcucumber.methods.MiscMethods;
import info.seleniumcucumber.methods.SelectElementByType;
import info.seleniumcucumber.methods.TestCaseFailed;


public class PredefinedStepDefinitions extends SelectElementByType implements BaseTest {

    String accessType;
    String accessValue;
    String element_text;

    //Navigation Steps

    //Step to navigate to specified URL
    @Given("^I navigate to \"([^\"]*)\"$")
    public void navigate_to(String app_name) {

        String link = MiscMethods.getConfig(app_name);
        navigationObj.navigateTo(link);
    }

    //Step to navigate to specified URL
    @Given("^I navigate to \"([^\"]*)\" with user \"([^\"]*)\"$")
    public void navigate_to_user(String app_name, String user) {

        String link = MiscMethods.getConfig(app_name);
        navigationObj.navigateTo(link, user);
    }

    //Step to navigate forward
    @Then("^I navigate forward")
    public void navigate_forward() {
        navigationObj.navigate("forward");
    }

    //Step to navigate backward
    @Then("^I navigate back")
    public void navigate_back() {
        navigationObj.navigate("back");
    }

    // steps to refresh page
    @Then("^I refresh page$")
    public void refresh_page() {
        navigationObj.refresh();
    }

    // Switch between windows

    //Switch to new window
    @Then("^I switch to new window$")
    public void switch_to_new_window() {
        navigationObj.switchToNewWindow();
    }

    //Switch to old window
    @Then("^I switch to previous window$")
    public void switch_to_old_window() {
        navigationObj.switchToOldWindow();
    }

    //Switch to new window by window title
    @Then("^I switch to window having title \"(.*?)\"$")
    public void switch_to_window_by_title(String windowTitle) throws Exception {
        navigationObj.switchToWindowByTitle(windowTitle);
    }

    //Close new window
    @Then("^I close new window$")
    public void close_new_window() {
        navigationObj.closeNewWindow();
    }

    // Switch between frame

    // Step to switch to frame by web element
    @Then("^I switch to frame named \"([^\"]*)\"$")
    public void switch_frame_by_element(String object_name) {

        accessType = ObjectRepository.getAccessType(object_name);
        accessValue = ObjectRepository.getAccessValue(object_name);
        navigationObj.switchFrame(accessType, accessValue);
    }

    // step to switch to main content
    @Then("^I switch to main content$")
    public void switch_to_default_content() {
        navigationObj.switchToDefaultContent();
    }

    // To interact with browser

    // step to resize browser
    @Then("^I resize browser window size to width (\\d+) and height (\\d+)$")
    public void resize_browser(int width, int heigth) {
        navigationObj.resizeBrowser(width, heigth);
    }

    // step to maximize browser
    @Then("^I maximize browser window$")
    public void maximize_browser() {
        navigationObj.maximizeBrowser();
    }

    //Step to close the browser
    @Then("^I close browser$")
    public void close_browser() {
        navigationObj.closeDriver();
    }

    //Step to close the browser
    @Then("^I quit browser$")
    public void quit_browser() {
        navigationObj.quitDriver();
    }


    // zoom in/out page

    // steps to zoom in page
    @Then("^I zoom in page$")
    public void zoom_in() {
        navigationObj.zoomInOut("ADD");
    }

    // steps to zoom out page
    @Then("^I zoom out page$")
    public void zoom_out() {
        navigationObj.zoomInOut("SUBTRACT");
    }

    // zoom out webpage till necessary element displays

    // steps to zoom out till element displays
    @Then("^I zoom out page till I see object named \"([^\"]*)\"$")
    public void zoom_till_element_display(String object_name) throws Exception {

        accessType = ObjectRepository.getAccessType(object_name);
        accessValue = ObjectRepository.getAccessValue(object_name);
        miscmethodObj.validateLocator(accessType);
        navigationObj.zoomInOutTillElementDisplay(accessType, "substract", accessValue);
    }

    // reset webpage view use

    @Then("^I reset page view$")
    public void reset_page_zoom() {
        navigationObj.zoomInOut("reset");
    }

    // scroll webpage

    @Then("^I scroll to (top|end) of page$")
    public void scroll_page(String to) throws Exception {
        navigationObj.scrollPage(to);
    }


    // scroll webpage to specific element

    @Then("^I scroll to the object named \"([^\"]*)\"$")
    public void scroll_to_element(String object_name) throws Exception {

        accessType = ObjectRepository.getAccessType(object_name);
        accessValue = ObjectRepository.getAccessValue(object_name);
        miscmethodObj.validateLocator(accessType);
        navigationObj.scrollToElement(accessType, accessValue);
    }


    // hover over element

    // Note: Doesn't work on Windows firefox
    @Then("^I hover over the object named \"([^\"]*)\"$")
    public void hover_over_element(String object_name) throws Exception {

        accessType = ObjectRepository.getAccessType(object_name);
        accessValue = ObjectRepository.getAccessValue(object_name);
        miscmethodObj.validateLocator(accessType);
        navigationObj.hoverOverElement(accessType, accessValue);
    }


    @Then("^I move to the object named \"([^\"]*)\"$")
    public void move_to_element(String object_name) throws Exception {

        accessType = ObjectRepository.getAccessType(object_name);
        accessValue = ObjectRepository.getAccessValue(object_name);
        miscmethodObj.validateLocator(accessType);
        navigationObj.moveToElement(accessType, accessValue);
    }


    //Assertion steps

    /**
     * page title checking
     *
     * @param present :
     * @param title   :
     */
    @Then("^I should\\s*((?:not)?)\\s+see page title as \"(.+)\"$")
    public void check_title(String present, String title) throws TestCaseFailed {
        //System.out.println("Present :" + present.isEmpty());
        assertionObj.checkTitle(title, present.isEmpty());
    }

    // step to check element partial text
    @Then("^I should\\s*((?:not)?)\\s+see page title having partial text as \"(.*?)\"$")
    public void check_partial_text(String present, String partialTextTitle) throws TestCaseFailed {
        //System.out.println("Present :" + present.isEmpty());
        assertionObj.checkPartialTitle(partialTextTitle, present.isEmpty());
    }

    // step to check element text
    @Then("^object named \"([^\"]*)\" should\\s*((?:not)?)\\s+have text as \"(.*?)\"$")
    public void check_element_text(String object_name, String present, String value) throws Exception {

        accessType = ObjectRepository.getAccessType(object_name);
        accessValue = ObjectRepository.getAccessValue(object_name);
        miscmethodObj.validateLocator(accessType);
        assertionObj.checkElementText(accessType, value, accessValue, present.isEmpty());
    }

    //step to check element partial text
    @Then("^object named \"([^\"]*)\" should\\s*((?:not)?)\\s+have partial text as \"(.*?)\"$")
    public void check_element_partial_text(String object_name, String present, String value) throws Exception {

        accessType = ObjectRepository.getAccessType(object_name);
        accessValue = ObjectRepository.getAccessValue(object_name);
        miscmethodObj.validateLocator(accessType);
        assertionObj.checkElementPartialText(accessType, value, accessValue, present.isEmpty());
    }

    // step to check attribute value
    @Then("^object named \"([^\"]*)\" should\\s*((?:not)?)\\s+have attribute \"(.*?)\" with value \"(.*?)\"$")
    public void check_element_attribute(String object_name, String present, String attrb, String value) throws Exception {

        accessType = ObjectRepository.getAccessType(object_name);
        accessValue = ObjectRepository.getAccessValue(object_name);
        miscmethodObj.validateLocator(accessType);
        assertionObj.checkElementAttribute(accessType, attrb, value, accessValue, present.isEmpty());
    }

    // step to check element enabled or not
    @Then("^object named \"([^\"]*)\" should\\s*((?:not)?)\\s+be (enabled|disabled)$")
    public void check_element_enable(String object_name, String present, String state) throws Exception {

        accessType = ObjectRepository.getAccessType(object_name);
        accessValue = ObjectRepository.getAccessValue(object_name);
        miscmethodObj.validateLocator(accessType);
        boolean flag = state.equals("enabled");
        if (!present.isEmpty()) {
            flag = !flag;
        }
        assertionObj.checkElementEnable(accessType, accessValue, flag);
    }

    //step to check element present or not
    @Then("^object named \"([^\"]*)\" should\\s*((?:not)?)\\s+be present$")
    public void check_element_presence(String object_name, String present) throws Exception {

        accessType = ObjectRepository.getAccessType(object_name);
        accessValue = ObjectRepository.getAccessValue(object_name);
        miscmethodObj.validateLocator(accessType);
        assertionObj.checkElementPresence(accessType, accessValue, present.isEmpty());
    }

    //step to assert checkbox is checked or unchecked
    @Then("^checkbox object named \"([^\"]*)\"  should be (checked|unchecked)$")
    public void is_checkbox_checked(String object_name, String state) throws Exception {

        accessType = ObjectRepository.getAccessType(object_name);
        accessValue = ObjectRepository.getAccessValue(object_name);
        miscmethodObj.validateLocator(accessType);
        boolean flag = state.equals("checked");
        assertionObj.isCheckboxChecked(accessType, accessValue, flag);
    }

    //steps to assert radio button checked or unchecked
    @Then("^radio button object named \"([^\"]*)\"  should be (selected|unselected)$")
    public void is_radio_button_selected(String object_name, String accessValue, String state) throws Exception {

        accessType = ObjectRepository.getAccessType(object_name);
        accessValue = ObjectRepository.getAccessValue(object_name);
        miscmethodObj.validateLocator(accessType);
        boolean flag = state.equals("selected");
        assertionObj.isRadioButtonSelected(accessType, accessValue, flag);
    }

    //steps to assert option by text from radio button group selected/unselected
    @Then("^option \"(.*?)\" by (.+) from radio button object named \"([^\"]*)\" should be (selected|unselected)$")
    public void is_option_from_radio_button_group_selected(String option, String attrb, String object_name, String state) throws Exception {

        accessType = ObjectRepository.getAccessType(object_name);
        accessValue = ObjectRepository.getAccessValue(object_name);
        miscmethodObj.validateLocator(accessType);
        boolean flag = state.equals("selected");
        assertionObj.isOptionFromRadioButtonGroupSelected(accessType, attrb, option, accessValue, flag);
    }

    //steps to check link presence
    @Then("^link having text \"(.*?)\" should\\s*((?:not)?)\\s+be present$")
    public void check_link_element_presence(String accessValue, String present) throws TestCaseFailed, Exception {
        assertionObj.checkElementPresence("linkText", accessValue, present.isEmpty());
    }

    //steps to check partail link presence
    @Then("^link having partial text \"(.*?)\" should\\s*((?:not)?)\\s+be present$")
    public void check_partial_link_element_presence(String accessValue, String present) throws TestCaseFailed, Exception {
        assertionObj.checkElementPresence("partialLinkText", accessValue, present.isEmpty());
    }

    //step to assert javascript pop-up alert text
    @Then("^I should see alert text as \"(.*?)\"$")
    public void check_alert_text(String actualValue) throws TestCaseFailed {
        assertionObj.checkAlertText(actualValue);
    }

    // step to select dropdown list
    @Then("^option \"(.*?)\" by (.+) from dropdown object named \"([^\"]*)\" should be (selected|unselected)$")
    public void is_option_from_dropdown_selected(String option, String by, String object_name, String state) throws Exception {

        accessType = ObjectRepository.getAccessType(object_name);
        accessValue = ObjectRepository.getAccessValue(object_name);
        miscmethodObj.validateLocator(accessType);
        boolean flag = state.equals("selected");
        assertionObj.isOptionFromDropdownSelected(accessType, by, option, accessValue, flag);
    }

    //Input steps

    // enter text into input field steps
    @Then("^I enter \"([^\"]*)\" into the input object named \"([^\"]*)\"$")
    public void i_enter_into_the_object_named(String text, String object_name) throws Throwable {


        accessType = ObjectRepository.getAccessType(object_name);
        accessValue = ObjectRepository.getAccessValue(object_name);
        miscmethodObj.validateLocator(accessType);
        if (text.equalsIgnoreCase("stored_value"))
            text = element_text;

        inputObj.enterText(accessType, text, accessValue);


    }


    // enter text into input field steps
    @Then("^I forcefully enter \"([^\"]*)\" into the input object named \"([^\"]*)\"$")
    public void i_enter_forcefully_into_the_object_named(String text, String object_name) throws Throwable {


        accessType = ObjectRepository.getAccessType(object_name);
        accessValue = ObjectRepository.getAccessValue(object_name);
        miscmethodObj.validateLocator(accessType);
        if (text.equalsIgnoreCase("stored_value"))
            text = element_text;

        inputObj.enterTextForcefully(accessType, text, accessValue);


    }

    // enter any KEY into input field steps
    @Then("^I enter \"([^\"]*)\" key into the input object named \"([^\"]*)\"$")
    public void i_enter_key_into_the_object_named(String text, String object_name) throws Throwable {


        accessType = ObjectRepository.getAccessType(object_name);
        accessValue = ObjectRepository.getAccessValue(object_name);
        miscmethodObj.validateLocator(accessType);
        inputObj.enterKey(accessType, text, accessValue);


    }

    // clear input field steps
    @Then("^I clear the input object named \"([^\"]*)\"$")
    public void clear_text(String object_name) throws Exception {

        accessType = ObjectRepository.getAccessType(object_name);
        accessValue = ObjectRepository.getAccessValue(object_name);
        miscmethodObj.validateLocator(accessType);
        inputObj.clearText(accessType, accessValue);
    }

    @Then("^I cleartext in the input object named \"([^\"]*)\"$")
    public void enter_text(String object_name) throws Exception {

        accessType = ObjectRepository.getAccessType(object_name);
        accessValue = ObjectRepository.getAccessValue(object_name);
        miscmethodObj.validateLocator(accessType);
        inputObj.clearAndEnterText(accessType, accessValue);
    }


    // select option by text/value from dropdown
    @Then("^I select \"(.*?)\" option by (.+) from dropdown object named \"([^\"]*)\"$")
    public void select_option_from_dropdown(String option, String optionBy, String object_name) throws Exception {

        accessType = ObjectRepository.getAccessType(object_name);
        accessValue = ObjectRepository.getAccessValue(object_name);
        miscmethodObj.validateLocator(accessType);
        miscmethodObj.validateOptionBy(optionBy);
        inputObj.selectOptionFromDropdown(accessType, optionBy, option, accessValue);
    }

    // select option by index from dropdown
    @Then("^I select (\\d+) option by index from dropdown object named \"([^\"]*)\"$")
    public void select_option_from_dropdown_by_index(String option, String object_name) throws Exception {

        accessType = ObjectRepository.getAccessType(object_name);
        accessValue = ObjectRepository.getAccessValue(object_name);
        miscmethodObj.validateLocator(accessType);
        inputObj.selectOptionFromDropdown(accessType, "selectByIndex", option, accessValue);
    }

    // select option by text/value from multiselect
    @Then("^I select \"(.*?)\" option by (.+) from multiselect dropdown object named \"([^\"]*)\"$")
    public void select_option_from_multiselect_dropdown(String option, String optionBy, String object_name) throws Exception {

        accessType = ObjectRepository.getAccessType(object_name);
        accessValue = ObjectRepository.getAccessValue(object_name);
        miscmethodObj.validateLocator(accessType);
        miscmethodObj.validateOptionBy(optionBy);
        inputObj.selectOptionFromDropdown(accessType, optionBy, option, accessValue);
    }

    // select option by index from multiselect
    @Then("^I select (\\d+) option by index from multiselect dropdown object named \"([^\"]*)\"$")
    public void select_option_from_multiselect_dropdown_by_index(String option, String object_name) throws Exception {

        accessType = ObjectRepository.getAccessType(object_name);
        accessValue = ObjectRepository.getAccessValue(object_name);
        miscmethodObj.validateLocator(accessType);
        inputObj.selectOptionFromDropdown(accessType, "selectByIndex", option, accessValue);
    }

    // deselect option by text/value from multiselect
    @Then("^I deselect \"(.*?)\" option by (.+) from multiselect dropdown object named \"([^\"]*)\"$")
    public void deselect_option_from_multiselect_dropdown(String option, String optionBy, String object_name) throws Exception {

        accessType = ObjectRepository.getAccessType(object_name);
        accessValue = ObjectRepository.getAccessValue(object_name);
        miscmethodObj.validateLocator(accessType);
        miscmethodObj.validateOptionBy(optionBy);
        inputObj.deselectOptionFromDropdown(accessType, optionBy, option, accessValue);
    }

    // deselect option by index from multiselect
    @Then("^I deselect (\\d+) option by index from multiselect dropdown object named \"([^\"]*)\"$")
    public void deselect_option_from_multiselect_dropdown_by_index(String option, String object_name) throws Exception {

        accessType = ObjectRepository.getAccessType(object_name);
        accessValue = ObjectRepository.getAccessValue(object_name);
        miscmethodObj.validateLocator(accessType);
        inputObj.deselectOptionFromDropdown(accessType, "selectByIndex", option, accessValue);
    }

    // step to select option from mutliselect dropdown list
	/*@Then("^I select all options from multiselect dropdown having (.+) \"(.*?)\"$")
	public void select_all_option_from_multiselect_dropdown(String accessType,String accessValue) throws Exception
	{
	miscmethod.validateLocator(accessType);
	//inputObj.
	//select_all_option_from_multiselect_dropdown(accessType, access_name)
	}*/

    // step to unselect option from mutliselect dropdown list
    @Then("^I deselect all options from multiselect dropdown object named \"([^\"]*)\"$")
    public void unselect_all_option_from_multiselect_dropdown(String object_name) throws Exception {

        accessType = ObjectRepository.getAccessType(object_name);
        accessValue = ObjectRepository.getAccessValue(object_name);
        miscmethodObj.validateLocator(accessType);
        inputObj.unselectAllOptionFromMultiselectDropdown(accessType, accessValue);
    }

    //check checkbox steps
    @Then("^I check the checkbox object named \"([^\"]*)\"$")
    public void check_checkbox(String object_name) throws Exception {

        accessType = ObjectRepository.getAccessType(object_name);
        accessValue = ObjectRepository.getAccessValue(object_name);
        miscmethodObj.validateLocator(accessType);
        inputObj.checkCheckbox(accessType, accessValue);
    }

    //uncheck checkbox steps
    @Then("^I uncheck the checkbox object named \"([^\"]*)\"$")
    public void uncheck_checkbox(String object_name) throws Exception {

        accessType = ObjectRepository.getAccessType(object_name);
        accessValue = ObjectRepository.getAccessValue(object_name);
        miscmethodObj.validateLocator(accessType);
        inputObj.uncheckCheckbox(accessType, accessValue);
    }

    //steps to toggle checkbox
    @Then("^I toggle checkbox object named \"([^\"]*)\"$")
    public void toggle_checkbox(String object_name) throws Exception {

        accessType = ObjectRepository.getAccessType(object_name);
        accessValue = ObjectRepository.getAccessValue(object_name);
        miscmethodObj.validateLocator(accessType);
        inputObj.toggleCheckbox(accessType, accessValue);
    }

    // step to select radio button
    @Then("^I select radio button object named \"([^\"]*)\"$")
    public void select_radio_button(String object_name) throws Exception {

        accessType = ObjectRepository.getAccessType(object_name);
        accessValue = ObjectRepository.getAccessValue(object_name);
        miscmethodObj.validateLocator(accessType);
        inputObj.selectRadioButton(accessType, accessValue);
    }

    // steps to select option by text from radio button group
    @Then("^I select \"(.*?)\" option by (.+) from radio button object named \"([^\"]*)\"$")
    public void select_option_from_radio_btn_group(String option, String by, String object_name) throws Exception {

        accessType = ObjectRepository.getAccessType(object_name);
        accessValue = ObjectRepository.getAccessValue(object_name);
        miscmethodObj.validateLocator(accessType);
        //miscmethodObj.validateOptionBy(optionBy);
        inputObj.selectOptionFromRadioButtonGroup(accessType, option, by, accessValue);
    }

    //Click element Steps
    // click on web element
    @Then("^I click on the object named \"([^\"]*)\"$")
    public void click(String object_name) throws Exception {
        accessType = ObjectRepository.getAccessType(object_name);
        accessValue = ObjectRepository.getAccessValue(object_name);
        miscmethodObj.validateLocator(accessType);
        clickObj.click(accessType, accessValue);
    }


    //Forcefully click on element
    @Then("^I forcefully click on the object named \"([^\"]*)\"$")
    public void click_forcefully(String object_name) throws Exception {

        accessType = ObjectRepository.getAccessType(object_name);
        accessValue = ObjectRepository.getAccessValue(object_name);
        miscmethodObj.validateLocator(accessType);
        clickObj.clickForcefully(accessType, accessValue);
    }


    // double click on web element
    @Then("^I double click on the object named \"([^\"]*)\"$")
    public void double_click(String object_name) throws Exception {

        accessType = ObjectRepository.getAccessType(object_name);
        accessValue = ObjectRepository.getAccessValue(object_name);
        miscmethodObj.validateLocator(accessType);
        clickObj.doubleClick(accessType, accessValue);
    }

    // steps to click on link
    @Then("^I click on link having text \"(.*?)\"$")
    public void click_link(String accessValue) {
        clickObj.click("linkText", accessValue);
    }

    //Step to click on partial link
    @Then("^I click on link having partial text \"(.*?)\"$")
    public void click_partial_link(String accessValue) {
        clickObj.click("partialLinkText", accessValue);
    }

    //Progress methods \"(.*?)\"

    // wait for specific period of time
    @Then("^I wait for (\\d+) sec$")
    public void wait(int time) throws NumberFormatException, InterruptedException,IllegalMonitorStateException {
        try {
            Thread.sleep(time*1000);
        }catch(Exception e){

        }
    }

    //wait for specific element to display for specific period of time
    @Then("^I wait (\\d+) seconds for the object named \"([^\"]*)\" to display$")
    public void wait_for_ele_to_display(int duration, String object_name) throws Exception {

        accessType = ObjectRepository.getAccessType(object_name);
        accessValue = ObjectRepository.getAccessValue(object_name);
        miscmethodObj.validateLocator(accessType);
        progressObj.waitForElementToDisplay(accessType, accessValue, duration);
        screenshotObj.takeScreenShot();
    }

    // wait for specific element to enable for specific period of time
    @Then("^I wait (\\d+) seconds for the object named \"([^\"]*)\" to enabled$")
    public void wait_for_ele_to_click(String duration, String object_name) throws Exception {

        accessType = ObjectRepository.getAccessType(object_name);
        accessValue = ObjectRepository.getAccessValue(object_name);
        miscmethodObj.validateLocator(accessType);
        progressObj.waitForElementToClick(accessType, accessValue, duration);
    }

    //JavaScript handling steps

    //Step to handle java script
    @Then("^I accept alert$")
    public void handle_alert() {
        javascriptObj.handleAlert("accept");
    }

    //Steps to dismiss java script
    @Then("^I dismiss alert$")
    public void dismiss_alert() {
        javascriptObj.handleAlert("dismiss");
    }

    //Screen shot methods

    @Then("^I take screenshot$")
    public void take_screenshot() throws IOException {
        screenshotObj.takeScreenShot();
    }

    //Configuration steps

    // step to print configuration
    @Then("^I print configuration$")
    public void print_config() {
        configObj.printDesktopConfiguration();
    }


    //Step to Cancel Print Window
    @Then("^I cancel the Print Window$")
    public void cancel_print_window() throws Exception {
        miscmethodObj.Cancel_Print();

    }

    // step to get element text
    @Then("^I get the text value on the object named \"(.*?)\"$")
    public void get_element_text(String object_name) throws Exception {

        accessType = ObjectRepository.getAccessType(object_name);
        accessValue = ObjectRepository.getAccessValue(object_name);
        miscmethodObj.validateLocator(accessType);
        element_text = assertionObj.getElementText(accessType, accessValue);

    }


    // step to upload a file
    @Then("^I upload file \"([^\"]*)\" into the input object named \"([^\"]*)\"$")
    public void upload_file(String filename, String object_name) throws Exception {

        accessType = ObjectRepository.getAccessType(object_name);
        accessValue = ObjectRepository.getAccessValue(object_name);
        miscmethodObj.validateLocator(accessType);
        inputObj.uploadFile(accessType, filename, accessValue);

    }


    @After
    public void embedScreenshotfail(Scenario scenario) {

        if ((scenario != null && scenario.isFailed() && MiscMethods.getConfig("screenshotLevel").equalsIgnoreCase("fail"))) {
            try {
                scenario.write("Current Page URL is " + assertionObj.getPageTitle());
                byte[] screenshot = ((TakesScreenshot) getDriver()).getScreenshotAs(OutputType.BYTES);
                scenario.embed(screenshot, "image/png");
            } catch (WebDriverException somePlatformsDontSupportScreenshots) {
                System.err.println(somePlatformsDontSupportScreenshots.getMessage());
            }

        }

        DriverUtil.closeDriver();


    }


    @AfterStep
    public void embedScreenshotAll(Scenario scenario) {

        if (MiscMethods.getConfig("screenshotLevel").equalsIgnoreCase("all") && scenario != null) {
            try {
                scenario.write("Current Page URL is " + assertionObj.getPageTitle());
                byte[] screenshot = ((TakesScreenshot) getDriver()).getScreenshotAs(OutputType.BYTES);
                scenario.embed(screenshot, "image/png");
            } catch (WebDriverException somePlatformsDontSupportScreenshots) {
                System.err.println(somePlatformsDontSupportScreenshots.getMessage());
            }

        }


    }


}