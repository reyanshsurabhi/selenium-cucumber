package env;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Platform;
import org.openqa.selenium.UnexpectedAlertBehaviour;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.ie.InternetExplorerOptions;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import info.seleniumcucumber.methods.MiscMethods;

/**
 *
 */
public class DriverUtil {
    public static long DEFAULT_WAIT = 1800;
    protected static WebDriver driver = null;
    static String currentPath = System.getProperty("user.dir");

    public static WebDriver getDefaultDriver(String user) {

        if (driver != null) {
            return driver;
        }
        System.setProperty("webdriver.chrome.driver", currentPath + "/src/test/resources/drivers/chromedriver.exe");
        System.setProperty("webdriver.ie.driver", currentPath + "/src/test/resources/drivers/IEDriverServer.exe");
        System.setProperty("webdriver.gecko.driver", currentPath + "/src/test/resources/drivers/geckodriver.exe");
        driver = chooseDriver(user);
        driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
        driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
        driver.manage().timeouts().setScriptTimeout(DEFAULT_WAIT, TimeUnit.SECONDS);
        driver.manage().window().maximize();
        return driver;
    }

    /**
     * @return
     */
    private static WebDriver chooseDriver(String user) {
        DesiredCapabilities capabilities = null;
        String preferredBrowser = MiscMethods.getConfig("browser");
        String Host = MiscMethods.getConfig("host");

        if (Host.equals("localhost")) {
            switch (preferredBrowser.toLowerCase()) {
                case "chrome":
                    System.out.println("Creating Chrome browser");
                    ChromeOptions options = new ChromeOptions();
                    options.merge(getCapabilities(preferredBrowser, user));
                    return new ChromeDriver(options);
                case "iexplore":
                    System.out.println("Creating iexplore browser");
                    InternetExplorerOptions internetExplorerOptions = new InternetExplorerOptions();
                    internetExplorerOptions.merge(getCapabilities(preferredBrowser, user));
                    return new InternetExplorerDriver(internetExplorerOptions);
                case "firefox":
                    System.out.println("Creating Firefox browser");
                    FirefoxOptions firefoxOptions = new FirefoxOptions();
                    firefoxOptions.merge(getCapabilities(preferredBrowser, user));
                    return new FirefoxDriver(firefoxOptions);
            }
        } else {

            String nodeURL = "http://" + MiscMethods.getConfig("host") + ":" + MiscMethods.getConfig("port") + "/wd/hub";
            try {
                System.out.println("Creating remote driver at "+ nodeURL);
                driver = new RemoteWebDriver(new URL(nodeURL), getCapabilities(preferredBrowser, user));
            } catch (MalformedURLException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
        return driver;

    }

    public static DesiredCapabilities getCapabilities(String browser, String user) {
        DesiredCapabilities capabilities = null;
        String chromeExtensionPath = currentPath + "/src/test/resources/Extn/" + user + "_auth_ext";
        switch (browser.toLowerCase()) {
            case "chrome":
                ChromeOptions chromeOptions = new ChromeOptions();
                if (!user.equals("")) {
                    chromeOptions.addArguments("load-extension=" + chromeExtensionPath);
                }
                chromeOptions.addArguments("--disable-notifications");
                capabilities = DesiredCapabilities.chrome();
                capabilities.setCapability(ChromeOptions.CAPABILITY, chromeOptions);
                return capabilities;
            case "iexplore":
                capabilities = DesiredCapabilities.internetExplorer();
                capabilities.setCapability(InternetExplorerDriver.NATIVE_EVENTS, false);
                capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
                capabilities.setCapability(InternetExplorerDriver.IGNORE_ZOOM_SETTING, true);
                capabilities.setCapability(CapabilityType.UNEXPECTED_ALERT_BEHAVIOUR, UnexpectedAlertBehaviour.DISMISS);
                return capabilities;
            case "firefox":
                FirefoxProfile profile = new FirefoxProfile();
                capabilities = DesiredCapabilities.firefox();
                capabilities.setCapability(FirefoxDriver.PROFILE, profile);
                capabilities.setCapability(CapabilityType.BROWSER_NAME, "firefox");
                FirefoxOptions options = new FirefoxOptions();
                capabilities.setJavascriptEnabled(true);
                capabilities.setCapability("takesScreenshot", true);
                capabilities.setCapability(FirefoxOptions.FIREFOX_OPTIONS, options);
                return capabilities;
        }
        return capabilities;
    }

    public static void closeDriver() {

        driver.close();
        driver.quit(); // fails in current geckodriver! TODO: Fixme
        driver = null;

    }


}
