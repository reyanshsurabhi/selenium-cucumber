package stepDefintions;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;

import io.cucumber.java.en.Then;
import info.seleniumcucumber.methods.BaseTest;
import info.seleniumcucumber.methods.SelectElementByType;


public class UserStepDefinitions  extends SelectElementByType implements BaseTest {
	
	// right click on web element
	@Then("^I right click on the object named \"([^\"]*)\"$")
	public void double_click(String object_name) throws Exception
	{
		
		String accessType =ObjectRepository.getAccessType(object_name);
		String accessValue =ObjectRepository.getAccessValue(object_name);
		WebElement element = getWait().until(ExpectedConditions.presenceOfElementLocated(getelementbytype(accessType, accessValue)));
		Actions action = new Actions(getDriver());
		action.moveToElement(element).contextClick().perform();
	}
	
	@Then("^I close the dialog window$")
	public void dialog_window_close() throws Exception
	{
		
		Actions builder = new Actions(getDriver());
		Action seriesOfActions = builder
			.sendKeys(Keys.TAB)
			.sendKeys(Keys.TAB)
			.sendKeys(Keys.ENTER)
			.pause(1000)
			.sendKeys(Keys.ENTER)
			.build();	
		seriesOfActions.perform() ;
		
	}
	
}
