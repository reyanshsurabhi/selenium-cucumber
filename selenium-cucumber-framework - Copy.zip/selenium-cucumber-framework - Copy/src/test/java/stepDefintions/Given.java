package stepDefintions;

public @interface Given {

}
