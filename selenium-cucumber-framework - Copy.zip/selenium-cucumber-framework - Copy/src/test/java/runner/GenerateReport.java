package runner;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

import net.masterthought.cucumber.Configuration;
import net.masterthought.cucumber.ReportBuilder;
import net.masterthought.cucumber.presentation.PresentationMode;
import net.masterthought.cucumber.sorting.SortingMethod;

public class GenerateReport {
	@Test
	public void generateReport() throws IOException {

	    	String currentPath = System.getProperty("user.dir");
	    	
	    	File reportOutputDirectory = new File("Reports");
	        List<String> jsonFiles = new ArrayList<>();
	        jsonFiles.add(currentPath+"\\target\\cucumber-reports\\Cucumber.json");

	        String buildNumber = "101";
	        String projectName = "Global Remittance BVT";
	        Configuration configuration = new Configuration(reportOutputDirectory, projectName);
	        configuration.setBuildNumber(buildNumber);

	        configuration.addClassifications("Browser", "IE");
	        configuration.addClassifications("Branch", "release/1.0");
	        configuration.setSortingMethod(SortingMethod.NATURAL);
	        configuration.addPresentationModes(PresentationMode.EXPAND_ALL_STEPS);
	        ReportBuilder reportBuilder = new ReportBuilder(jsonFiles, configuration);
	        reportBuilder.generateReports();
	    }
	
}
