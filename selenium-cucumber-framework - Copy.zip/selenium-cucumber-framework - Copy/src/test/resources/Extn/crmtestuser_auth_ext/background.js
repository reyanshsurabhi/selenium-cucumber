
var username = "crmtestuser2";
var password = "Sprin!gTest02";
var retry = 3;

chrome.webRequest.onAuthRequired.addListener(
  function handler(details) {    
    if (--retry < 0)
      return {cancel: true};
    return {authCredentials: {username: username, password: password}};
  },
  {urls: ["<all_urls>"]},
  ['blocking']
);

