
var username = "crmtestuser3";
var password = "W!nterTest83";
var retry = 3;

chrome.webRequest.onAuthRequired.addListener(
  function handler(details) {    
    if (--retry < 0)
      return {cancel: true};
    return {authCredentials: {username: username, password: password}};
  },
  {urls: ["<all_urls>"]},
  ['blocking']
);

