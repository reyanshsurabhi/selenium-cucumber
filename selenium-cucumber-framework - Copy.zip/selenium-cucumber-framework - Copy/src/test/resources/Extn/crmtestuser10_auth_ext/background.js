
var username = "crmtestuser10";
var password = "W!nterTest20";
var retry = 3;

chrome.webRequest.onAuthRequired.addListener(
  function handler(details) {    
    if (--retry < 0)
      return {cancel: true};
    return {authCredentials: {username: username, password: password}};
  },
  {urls: ["<all_urls>"]},
  ['blocking']
);

